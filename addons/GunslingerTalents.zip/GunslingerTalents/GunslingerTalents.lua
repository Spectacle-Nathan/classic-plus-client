-- Custom WoW Client Addon: Gunslinger Talents Frame
-- Allows allocating, resetting, and activating subclass talents.
-- Author: Antigravity

local ADDON_PREFIX = "GunslingerTalents"
local talentRanks = {}
for i = 1, 19 do talentRanks[i] = 0 end
local totalSpent = 0
local freePoints = 0

-- Talent Definitions (matching server)
local TALENTS = {
    -- Tree 1: Catalyst
    { id = 1, tree = 1, row = 1, col = 1, name = "Ignited Powder", max = 5, desc = "Auto-attacks have a 4/8/12/16/20% chance to trigger Scorching Shot, dealing Fire damage." },
    { id = 2, tree = 1, row = 1, col = 2, name = "Static Chamber", max = 5, desc = "Nature/Fire spell procs have a 20/40/60/80/100% chance to apply static charge, reducing resistances by 15. Stacks 3x." },
    { id = 3, tree = 1, row = 2, col = 1, name = "Chain Reaction", max = 1, desc = "Active (20s CD): Next auto-attack triggers all learned elemental procs, arcing to 2 nearby targets.", isActive = true },
    { id = 4, tree = 1, row = 3, col = 1, name = "Conductive Barrels", max = 3, desc = "Elemental procs gain 15/30/45% flat scaling from total Equipment Spell Damage." },
    { id = 5, tree = 1, row = 3, col = 2, name = "Superconductor", max = 3, desc = "Melee weapon enchants have a 33/66/100% chance to instantly fire a free Scorching Shot." },
    { id = 6, tree = 1, row = 4, col = 1, name = "Elemental Attunement", max = 1, desc = "Custom spell procs gain +15% critical strike chance if target has magical vulnerabilities." },
    { id = 7, tree = 1, row = 5, col = 1, name = "Elemental Cascade", max = 1, desc = "Active (3m CD): Increases ranged haste by 30% for 15s. Procs have a 30% chance to trigger secondary blasts.", isActive = true },

    -- Tree 2: Fortune
    { id = 8, tree = 2, row = 1, col = 1, name = "Loaded Dice", max = 5, desc = "Converts 20/40/60/80/100% of Equipment Critical Strike Chance % into custom Luck stat." },
    { id = 9, tree = 2, row = 1, col = 2, name = "The House Always Wins", max = 5, desc = "Auto-attacks that fail to proc increase Luck by 5/10/15/20/25% (resets on proc)." },
    { id = 10, tree = 2, row = 2, col = 1, name = "Under the Table", max = 1, desc = "Active (1.5m CD): Grants 300% extra Luck for the next 3 auto-attacks, virtually guaranteeing procs.", isActive = true },
    { id = 11, tree = 2, row = 3, col = 1, name = "Sleight of Hand", max = 5, desc = "Auto-attacks have a 0.1/0.2/0.3/0.4/0.5% chance per point of Luck to trigger equipped enchants." },
    { id = 12, tree = 2, row = 4, col = 1, name = "Hand of Fate", max = 1, desc = "Doubles the proc chances of Superconductor and The House Always Wins." },
    { id = 13, tree = 2, row = 5, col = 1, name = "Jackpot", max = 1, desc = "Active (5m CD): Forces all equipped item procs, trinkets, and enchants to trigger simultaneously on the target.", isActive = true },

    -- Tree 3: Munitions
    { id = 14, tree = 3, row = 1, col = 1, name = "Shrapnel Shells", max = 5, desc = "Single-target elemental and item procs splash, dealing 10/20/30/40/50% damage to all enemies within 5yd." },
    { id = 15, tree = 3, row = 1, col = 2, name = "Heavy Caliber", max = 5, desc = "Converts 20/40/60/80/100% of physical Attack Power into bonus flat damage for physical item procs." },
    { id = 16, tree = 3, row = 2, col = 1, name = "Concussive Blast", max = 1, desc = "Active (30s CD): Fires a shell that stuns the target for 3s if any proc occurs within 2s.", isActive = true },
    { id = 17, tree = 3, row = 3, col = 1, name = "Alchemical Powder", max = 3, desc = "Physical item procs ignore 10/20/30% of target's armor." },
    { id = 18, tree = 3, row = 4, col = 1, name = "Cluster Munitions", max = 1, desc = "Auto-attacks split into a frontal cone striking 2 additional targets (50% reduced proc chance)." },
    { id = 19, tree = 3, row = 5, col = 1, name = "Carpet Bomber", max = 1, desc = "Active (2m CD): For 12s, auto-attacks explode in a 10yd zone. Every target rolls procs independently.", isActive = true }
}

-- Create the main UI frame
local frame = CreateFrame("Frame", "GunslingerTalentFrame", UIParent)
frame:SetSize(720, 520)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:Hide()

frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 }
})

-- Header Title
local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOP", 0, -18)
title:SetText("Gunslinger Class Talents")

-- Points Label
local pointsText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
pointsText:SetPoint("TOPLEFT", 25, -20)
pointsText:SetText("Points: 0")

-- Close Button
local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -8, -8)

-- Tab Headers
local headers = { "Catalyst (Spell Dmg)", "Fortune (High Roller)", "Munitions (AoE)" }
local columns = {}

for colIdx = 1, 3 do
    local col = CreateFrame("Frame", nil, frame)
    col:SetSize(220, 400)
    col:SetPoint("TOPLEFT", 18 + (colIdx - 1) * 230, -50)
    
    col:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    col:SetBackdropColor(0.05, 0.05, 0.05, 0.8)
    
    local colTitle = col:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    colTitle:SetPoint("TOP", 0, -10)
    colTitle:SetText(headers[colIdx])
    
    columns[colIdx] = col
end

-- Render all talent buttons
local buttons = {}
for _, t in ipairs(TALENTS) do
    local parent = columns[t.tree]
    local btn = CreateFrame("Button", "GunslingerTalentBtn_" .. t.id, parent)
    btn:SetSize(44, 44)
    -- Calculate coordinates (X-col, Y-row)
    local xOffset = 30 + (t.col - 1) * 70
    local yOffset = -40 - (t.row - 1) * 70
    btn:SetPoint("TOPLEFT", xOffset, yOffset)
    
    -- Icon texture
    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetAllPoints()
    if t.isActive then
        icon:SetTexture("Interface\\Icons\\Spell_Holy_MindVision") -- Active spell icon
    else
        icon:SetTexture("Interface\\Icons\\Ability_Hunter_MasterMarksman") -- Passive icon
    end
    btn.icon = icon
    
    -- Border frame (color by tree)
    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetSize(62, 62)
    border:SetPoint("CENTER", 0, 0)
    if t.tree == 1 then
        border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
        border:SetVertexColor(0.7, 0.3, 1.0) -- Purple theme
    elseif t.tree == 2 then
        border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
        border:SetVertexColor(1.0, 0.8, 0.0) -- Gold theme
    else
        border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
        border:SetVertexColor(1.0, 0.3, 0.0) -- Orange theme
    end
    btn.border = border
    
    -- Counter label (ranks)
    local count = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    count:SetPoint("BOTTOMRIGHT", 2, -2)
    count:SetText("0/" .. t.max)
    btn.count = count
    
    -- Mouse interactions
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(t.name, 1, 1, 1)
        if t.isActive then
            GameTooltip:AddLine("Active Ability", 0.5, 0.9, 1.0)
        else
            GameTooltip:AddLine("Passive Talent", 0.7, 0.7, 0.7)
        end
        GameTooltip:AddLine("Rank: " .. talentRanks[t.id] .. "/" .. t.max, 0, 1, 0)
        GameTooltip:AddLine(t.desc, 0.8, 0.8, 0.8, true)
        
        -- Show hotkey helper for active abilities
        if t.isActive and talentRanks[t.id] > 0 then
            GameTooltip:AddLine("Click / Use to cast (Sends trigger packet)", 0.2, 1.0, 0.5)
        end
        
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    
    btn:SetScript("OnClick", function(self, button)
        if t.isActive and talentRanks[t.id] > 0 then
            -- Cast / Activate talent
            SendAddonMessage(ADDON_PREFIX, "UseActive:" .. t.id, "WHISPER", UnitName("player"))
        else
            -- Spend point
            SendAddonMessage(ADDON_PREFIX, "Learn:" .. t.id, "WHISPER", UnitName("player"))
        end
    end)
    
    buttons[t.id] = btn
end

-- Reset Button
local resetBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
resetBtn:SetSize(120, 24)
resetBtn:SetPoint("BOTTOMLEFT", 25, 20)
resetBtn:SetText("Reset Talents")
resetBtn:SetScript("OnClick", function()
    PlaySound("igMainMenuOption")
    SendAddonMessage(ADDON_PREFIX, "Reset", "WHISPER", UnitName("player"))
end)

-- Help Label
local helpText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
helpText:SetPoint("BOTTOMRIGHT", -25, 20)
helpText:SetText("Slash commands: /talents or /gunslinger")

-- Update UI fields
local function UpdateUI()
    pointsText:SetText("Available Points: |cff00ff00" .. freePoints .. "|r")
    
    for i = 1, 19 do
        local btn = buttons[i]
        if btn then
            local rank = talentRanks[i] or 0
            local max = TALENTS[i].max
            btn.count:SetText(rank .. "/" .. max)
            
            -- Color icon based on rank
            if rank > 0 then
                btn.icon:SetDesaturated(false)
            else
                btn.icon:SetDesaturated(true)
            end
        end
    end
end

-- Register Slash Commands at load time
SLASH_GUNSLINGER1 = "/gunslinger"
SlashCmdList["GUNSLINGER"] = function(msg)
    if GunslingerTalentFrame:IsShown() then
        GunslingerTalentFrame:Hide()
    else
        GunslingerTalentFrame:Show()
        -- Ask server for update
        SendAddonMessage(ADDON_PREFIX, "SyncRequest", "WHISPER", UnitName("player"))
    end
end

SLASH_TALENTS1 = "/talents"
SlashCmdList["TALENTS"] = function(msg)
    local _, class = UnitClass("player")
    if class == "HUNTER" then
        if GunslingerTalentFrame:IsShown() then
            GunslingerTalentFrame:Hide()
        else
            GunslingerTalentFrame:Show()
            SendAddonMessage("GunslingerTalents", "SyncRequest", "WHISPER", UnitName("player"))
        end
    elseif class == "DEATHKNIGHT" then
        if SpellslingerTalentFrame and SpellslingerTalentFrame:IsShown() then
            SpellslingerTalentFrame:Hide()
        elseif SpellslingerTalentFrame then
            SpellslingerTalentFrame:Show()
            SendAddonMessage("SpellslingerTalents", "SyncRequest", "WHISPER", UnitName("player"))
        end
    end
end

-- Network/Addon Msg Event Register
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_LEVEL_UP")

eventFrame:SetScript("OnEvent", function(self, event, prefix, msg, channel, sender)
    if event == "PLAYER_LOGIN" then
        -- Load initial state
        RegisterAddonMessagePrefix(ADDON_PREFIX)
        UpdateUI()
    elseif event == "PLAYER_LEVEL_UP" then
        UpdateUI()
    elseif event == "CHAT_MSG_ADDON" and prefix == ADDON_PREFIX then
        if msg:find("^Sync:") then
            -- Format: Sync:r1:r2:...:r19:totalSpent:freePoints
            local parts = {}
            for val in string.gmatch(msg, "([^:]+)") do
                table.insert(parts, val)
            end
            
            if #parts >= 22 then -- "Sync" + 19 ranks + totalSpent + freePoints
                for i = 1, 19 do
                    talentRanks[i] = tonumber(parts[i + 1]) or 0
                end
                totalSpent = tonumber(parts[21]) or 0
                freePoints = tonumber(parts[22]) or 0
                UpdateUI()
            end
        end
    end
end)

DEFAULT_CHAT_FRAME:AddMessage("|cff00ffff[GunslingerTalents]: Addon loaded. Type /talents to open talent tree.|r")
