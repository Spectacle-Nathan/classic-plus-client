-- MapVisualizer: Sleek, glassmorphic slide-in panel showing active dungeon map affixes (Client-Side)
-- Author: Antigravity

local ADDON_PREFIX = "MapVisualizer"
local DUNGEON_NAMES = {
    [36] = "The Deadmines",
    [43] = "Wailing Caverns",
    [33] = "Shadowfang Keep",
    [48] = "Blackfathom Deeps",
    [34] = "The Stockade",
    [90] = "Gnomeregan",
    [189] = "Scarlet Monastery",
    [47] = "Razorfen Kraul",
    [129] = "Razorfen Downs",
    [209] = "Zul'Farrak",
    [109] = "Sunken Temple",
    [230] = "Blackrock Depths",
    [289] = "Scholomance",
    [329] = "Stratholme"
}

local AFFIX_INFO = {
    volcanic = {
        name = "Volcanic",
        desc = "Volcanoes periodically erupt under the feet of random players in combat.",
        icon = "Interface\\Icons\\Spell_Fire_LavaSpit",
        color = { r = 1.0, g = 0.4, b = 0.0 }
    },
    sanguine = {
        name = "Sanguine",
        desc = "Defeated enemies leave behind a pool of blood that heals allies and hurts players.",
        icon = "Interface\\Icons\\Spell_Shadow_BloodBoil",
        color = { r = 0.8, g = 0.1, b = 0.1 }
    },
    bolstering = {
        name = "Bolstering",
        desc = "Summoned minions bolster the boss on death, increasing damage and size.",
        icon = "Interface\\Icons\\Spell_Nature_StrengthOfEarthTotem",
        color = { r = 0.9, g = 0.8, b = 0.2 }
    },
    explosive = {
        name = "Explosive",
        desc = "Explosive Orbs spawn periodically in combat and must be killed before they detonate.",
        icon = "Interface\\Icons\\Spell_Fire_SelfDestruct",
        color = { r = 1.0, g = 0.2, b = 0.2 }
    },
    necrotic = {
        name = "Necrotic",
        desc = "Boss melee attacks apply a stacking blight that reduces healing received.",
        icon = "Interface\\Icons\\Spell_Shadow_AnimateDead",
        color = { r = 0.2, g = 0.8, b = 0.2 }
    },
    quaking = {
        name = "Quaking",
        desc = "Periodic earthquakes interrupt spell casting and silence affected players.",
        icon = "Interface\\Icons\\Spell_Nature_Earthquake",
        color = { r = 0.7, g = 0.5, b = 0.3 }
    }
}

-- Create the main UI panel frame
local frame = CreateFrame("Frame", "MapVisualizerFrame", UIParent)
frame:SetSize(220, 310)
frame:SetFrameStrata("MEDIUM")

-- Config coordinates for transition
frame.openX = -15
frame.closedX = 235
frame.yOffset = 80
frame.currX = frame.closedX
frame.targetX = frame.closedX
frame.animating = false

frame:SetPoint("RIGHT", UIParent, "RIGHT", frame.currX, frame.yOffset)

-- Premium glassmorphic background
frame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
frame:SetBackdropColor(0.02, 0.03, 0.06, 0.82) -- Translucent deep blue/black
frame:SetBackdropBorderColor(0.45, 0.25, 0.75, 0.85) -- Violet glowing border

-- Main Header Label
local lblHeader = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
lblHeader:SetPoint("TOP", 0, -12)
lblHeader:SetText("MAPPED DUNGEON")
lblHeader:SetTextColor(0.55, 0.55, 0.7)

-- Dungeon Name Label
local lblDungeonName = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
lblDungeonName:SetPoint("TOP", lblHeader, "BOTTOM", 0, -4)
lblDungeonName:SetText("Unknown Map")
lblDungeonName:SetTextColor(1.0, 1.0, 1.0)

-- Keystone Level Label
local lblKeystone = frame:CreateFontString(nil, "OVERLAY")
lblKeystone:SetFont("Fonts\\FRIZQT__.TTF", 13, "OUTLINE")
lblKeystone:SetPoint("TOP", lblDungeonName, "BOTTOM", 0, -4)
lblKeystone:SetText("Keystone +0")
lblKeystone:SetTextColor(1.0, 0.85, 0.3) -- Light gold

-- Divider 1
local div1 = frame:CreateTexture(nil, "BACKGROUND")
div1:SetSize(190, 1)
div1:SetPoint("TOP", lblKeystone, "BOTTOM", 0, -8)
div1:SetTexture(0.45, 0.25, 0.75, 0.3) -- Violet line

-- Stats Section: Quantity, Rarity, HP/Damage
local function CreateStatRow(parent, relativeTo, labelText, colorStr, iconTexture)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(190, 20)
    row:SetPoint("TOPLEFT", relativeTo, "BOTTOMLEFT", 0, -6)
    
    local icon = row:CreateTexture(nil, "ARTWORK")
    icon:SetSize(14, 14)
    icon:SetPoint("LEFT", 0, 0)
    icon:SetTexture(iconTexture)
    
    local valueText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    valueText:SetPoint("RIGHT", 0, 0)
    valueText:SetTextColor(0.9, 0.9, 0.9)
    
    local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    nameText:SetPoint("LEFT", icon, "RIGHT", 6, 0)
    nameText:SetText(labelText)
    nameText:SetTextColor(0.65, 0.65, 0.75)
    
    return row, valueText
end

local rowQty, txtQty = CreateStatRow(frame, div1, "Item Quantity:", "|cff22aa22", "Interface\\Icons\\inv_misc_bag_10_blue")
local rowRar, txtRar = CreateStatRow(frame, rowQty, "Item Rarity:", "|cff5588ff", "Interface\\Icons\\inv_misc_gem_amethyst_01")
local rowMult, txtMult = CreateStatRow(frame, rowRar, "Mob Strength:", "|cffdd2222", "Interface\\Icons\\Ability_Creature_Disease_05")

-- Divider 2
local div2 = frame:CreateTexture(nil, "BACKGROUND")
div2:SetSize(190, 1)
div2:SetPoint("TOP", rowMult, "BOTTOM", 0, -8)
div2:SetTexture(0.45, 0.25, 0.75, 0.3)

-- Affixes Title
local lblAffixesTitle = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
lblAffixesTitle:SetPoint("TOPLEFT", div2, "BOTTOMLEFT", 4, -8)
lblAffixesTitle:SetText("ACTIVE MODIFIERS")
lblAffixesTitle:SetTextColor(0.55, 0.55, 0.7)

-- Container for dynamic affixes
local affixContainer = CreateFrame("Frame", nil, frame)
affixContainer:SetSize(190, 130)
affixContainer:SetPoint("TOPLEFT", lblAffixesTitle, "BOTTOMLEFT", -4, -4)

local affixRows = {}

-- Function to dynamically render affixes in the container
local function UpdateAffixList(affixesCsv)
    -- Clear current rows
    for _, r in ipairs(affixRows) do
        r:Hide()
    end
    
    local parsed = {}
    if affixesCsv and affixesCsv ~= "" then
        for aff in string.gmatch(affixesCsv, "([^,]+)") do
            table.insert(parsed, aff:lower():trim())
        end
    end
    
    if #parsed == 0 then
        local noAffixRow = affixRows[1] or CreateFrame("Frame", nil, affixContainer)
        noAffixRow:SetSize(190, 24)
        noAffixRow:SetPoint("TOPLEFT", affixContainer, "TOPLEFT", 4, -8)
        noAffixRow:Show()
        
        if not noAffixRow.text then
            noAffixRow.text = noAffixRow:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            noAffixRow.text:SetPoint("LEFT", 0, 0)
        end
        noAffixRow.text:SetText("None (Normal Run)")
        noAffixRow.text:SetTextColor(0.5, 0.5, 0.5)
        if noAffixRow.icon then noAffixRow.icon:Hide() end
        affixRows[1] = noAffixRow
        return
    end
    
    for idx, affKey in ipairs(parsed) do
        local info = AFFIX_INFO[affKey]
        if info then
            local row = affixRows[idx]
            if not row then
                row = CreateFrame("Frame", nil, affixContainer)
                row:SetSize(190, 24)
                
                local icon = row:CreateTexture(nil, "ARTWORK")
                icon:SetSize(18, 18)
                icon:SetPoint("LEFT", 4, 0)
                row.icon = icon
                
                local text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                text:SetPoint("LEFT", icon, "RIGHT", 8, 0)
                row.text = text
                
                -- Highlight hover backdrop
                row:SetBackdrop({
                    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
                    tile = true, tileSize = 16,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                row:SetBackdropColor(1.0, 1.0, 1.0, 0)
                
                row:SetScript("OnEnter", function(self)
                    self:SetBackdropColor(0.45, 0.25, 0.75, 0.15)
                    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
                    GameTooltip:SetText(info.name, info.color.r, info.color.g, info.color.b)
                    GameTooltip:AddLine(info.desc, 1, 1, 1, true)
                    GameTooltip:Show()
                end)
                
                row:SetScript("OnLeave", function(self)
                    self:SetBackdropColor(1.0, 1.0, 1.0, 0)
                    GameTooltip:Hide()
                end)
                
                affixRows[idx] = row
            end
            
            row:SetPoint("TOPLEFT", affixContainer, "TOPLEFT", 0, -4 - ((idx - 1) * 26))
            row.icon:SetTexture(info.icon)
            row.icon:Show()
            row.text:SetText(info.name)
            row.text:SetTextColor(info.color.r, info.color.g, info.color.b)
            row:Show()
        end
    end
end

-- Create the Toggle Tab Button
local toggleBtn = CreateFrame("Button", "MapVisualizerToggleBtn", frame)
toggleBtn:SetSize(16, 52)
toggleBtn:SetPoint("RIGHT", frame, "LEFT", 1, 0)

toggleBtn:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 8,
    insets = { left = 2, right = 2, top = 2, bottom = 2 }
})
toggleBtn:SetBackdropColor(0.02, 0.03, 0.06, 0.82)
toggleBtn:SetBackdropBorderColor(0.45, 0.25, 0.75, 0.85)

local toggleTxt = toggleBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
toggleTxt:SetPoint("CENTER", 0, 0)
toggleTxt:SetText("<")
toggleTxt:SetTextColor(0.8, 0.7, 0.9)

toggleBtn:SetScript("OnEnter", function(self)
    self:SetBackdropBorderColor(0.65, 0.45, 0.95, 1.0)
    toggleTxt:SetTextColor(1.0, 0.9, 1.0)
end)

toggleBtn:SetScript("OnLeave", function(self)
    self:SetBackdropBorderColor(0.45, 0.25, 0.75, 0.85)
    toggleTxt:SetTextColor(0.8, 0.7, 0.9)
end)

toggleBtn:SetScript("OnClick", function()
    PlaySound("igMainMenuOption")
    if frame.targetX == frame.openX then
        frame.targetX = frame.closedX
        toggleTxt:SetText("<")
    else
        frame.targetX = frame.openX
        toggleTxt:SetText(">")
    end
    frame.animating = true
end)

-- Smooth animation using exponential lerp in OnUpdate
local animSpeed = 9.0
frame:SetScript("OnUpdate", function(self, elapsed)
    if self.animating then
        local curr = self.currX
        local targ = self.targetX
        local diff = targ - curr
        
        if math.abs(diff) < 0.2 then
            self.currX = targ
            self.animating = false
            self:SetPoint("RIGHT", UIParent, "RIGHT", targ, self.yOffset)
        else
            self.currX = curr + diff * math.min(1, elapsed * animSpeed)
            self:SetPoint("RIGHT", UIParent, "RIGHT", self.currX, self.yOffset)
        end
    end
end)

-- Network communication and sync requests
local function SendSyncRequest()
    SendAddonMessage(ADDON_PREFIX, "RequestSync", "WHISPER", UnitName("player"))
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")

eventFrame:SetScript("OnEvent", function(self, event, prefix, msg, channel, sender)
    if event == "PLAYER_LOGIN" then
        RegisterAddonMessagePrefix(ADDON_PREFIX)
        SendSyncRequest()
    elseif event == "ZONE_CHANGED_NEW_AREA" or event == "PLAYER_ENTERING_WORLD" then
        SendSyncRequest()
    elseif event == "CHAT_MSG_ADDON" and prefix == ADDON_PREFIX then
        if msg:find("^Active:") then
            -- Payload format: Active:mapId,keyLevel,quantity,rarity,affixesCsv
            local data = msg:sub(8)
            local mapId, keyLevel, quantity, rarity, affixesCsv = string.match(data, "^([^,]+),([^,]+),([^,]+),([^,]+),*(.*)")
            
            if mapId then
                local mNum = tonumber(mapId)
                local dungName = DUNGEON_NAMES[mNum] or "Unknown Instance"
                local kNum = tonumber(keyLevel) or 0
                local qNum = tonumber(quantity) or 0
                local rNum = tonumber(rarity) or 0
                
                lblDungeonName:SetText(dungName)
                lblKeystone:SetText("Keystone +" .. kNum)
                
                txtQty:SetText("|cff22aa22+" .. qNum .. "%|r")
                txtRar:SetText("|cff5588ff+" .. rNum .. "%|r")
                
                local mobScale = kNum * 8
                txtMult:SetText("|cffdd2222+" .. mobScale .. "%|r")
                
                UpdateAffixList(affixesCsv)
                
                -- Trigger slide-in
                frame.targetX = frame.openX
                toggleTxt:SetText(">")
                frame.animating = true
            end
        elseif msg == "Inactive" then
            -- Trigger slide-out
            frame.targetX = frame.closedX
            toggleTxt:SetText("<")
            frame.animating = true
        end
    end
end)

DEFAULT_CHAT_FRAME:AddMessage("|cff00ffff[MapVisualizer] Addon loaded successfully!|r")
