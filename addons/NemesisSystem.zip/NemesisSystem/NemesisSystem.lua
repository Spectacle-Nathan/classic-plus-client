-- Custom WoW Client Addon: Nemesis & Rival System UI
-- Tracks active rivals, PvP stats, and allows manually triggering invasions.
-- Author: Antigravity

local ADDON_PREFIX = "NemesisSystem"
local rivalsList = {} -- { {name, level, raceId, classId, victories, defeats, rank}, ... }
local selectedRivalIdx = nil

local RACES = {
    [1] = "Human", [2] = "Orc", [3] = "Dwarf", [4] = "Night Elf",
    [5] = "Undead", [6] = "Tauren", [7] = "Gnome", [8] = "Troll",
    [10] = "Blood Elf", [11] = "Draenei"
}

local CLASSES = {
    [1] = "Warrior", [2] = "Paladin", [3] = "Hunter", [4] = "Rogue",
    [5] = "Priest", [6] = "Death Knight", [7] = "Shaman", [8] = "Mage",
    [9] = "Warlock", [11] = "Druid"
}

local RANK_TITLES = {
    [0] = "Neutral",
    [1] = "Scourge",
    [2] = "Marauder",
    [3] = "Slayer",
    [4] = "Dreadlord",
    [5] = "Grand Inquisitor"
}

local RANK_COLORS = {
    [0] = "|cff808080", -- Grey
    [1] = "|cff00ff00", -- Green
    [2] = "|cff00ffff", -- Cyan
    [3] = "|cff9370db", -- Purple
    [4] = "|cffffa500", -- Orange
    [5] = "|cffff0000"  -- Red
}

-- Create the main UI frame
local frame = CreateFrame("Frame", "NemesisFrame", UIParent)
frame:SetSize(650, 420)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:Hide()

frame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
frame:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
frame:SetBackdropBorderColor(0.2, 0.2, 0.25, 0.8)

-- Header Title
local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOP", 0, -15)
title:SetText("Rivalries & Nemesis System")

-- Close Button
local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -4, -4)

-- Left Panel: Rivals List
local listPanel = CreateFrame("Frame", nil, frame)
listPanel:SetSize(280, 350)
listPanel:SetPoint("TOPLEFT", 15, -45)
listPanel:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
listPanel:SetBackdropColor(0.02, 0.02, 0.03, 0.7)
listPanel:SetBackdropBorderColor(0.15, 0.15, 0.2, 0.8)

local listTitle = listPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
listTitle:SetPoint("TOP", 0, -8)
listTitle:SetText("Your Rivals")

-- Scroll Frame for Rivals List
local scrollFrame = CreateFrame("ScrollFrame", "NemesisRivalScrollFrame", listPanel, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", 8, -30)
scrollFrame:SetPoint("BOTTOMRIGHT", -26, 8)

local scrollChild = CreateFrame("Frame", nil, scrollFrame)
scrollChild:SetSize(246, 310)
scrollFrame:SetScrollChild(scrollChild)

-- Right Panel: Rival Details & Hunt Button
local detailsPanel = CreateFrame("Frame", nil, frame)
detailsPanel:SetSize(320, 350)
detailsPanel:SetPoint("TOPRIGHT", -15, -45)
detailsPanel:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
detailsPanel:SetBackdropColor(0.02, 0.02, 0.03, 0.7)
detailsPanel:SetBackdropBorderColor(0.15, 0.15, 0.2, 0.8)

local detailsTitle = detailsPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
detailsTitle:SetPoint("TOP", 0, -8)
detailsTitle:SetText("Rival Details")

-- Detail Text Strings
local detailName = detailsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
detailName:SetPoint("TOPLEFT", 15, -35)
detailName:SetText("Select a rival from the list")

local detailInfo = detailsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
detailInfo:SetPoint("TOPLEFT", 15, -60)
detailInfo:SetJustifyH("LEFT")
detailInfo:SetText("")

local detailStats = detailsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
detailStats:SetPoint("TOPLEFT", 15, -110)
detailStats:SetJustifyH("LEFT")
detailStats:SetText("")

-- Hunt Trigger Button
local huntBtn = CreateFrame("Button", "NemesisHuntBtn", detailsPanel, "UIPanelButtonTemplate")
huntBtn:SetSize(140, 32)
huntBtn:SetPoint("TOP", 0, -170)
huntBtn:SetText("Incite Hunt")
huntBtn:Hide()

-- System Instructions & Help Text
local instructions = detailsPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
instructions:SetPoint("BOTTOMLEFT", 15, 12)
instructions:SetPoint("BOTTOMRIGHT", -15, 12)
instructions:SetJustifyH("LEFT")
instructions:SetJustifyV("BOTTOM")
instructions:SetSpacing(3)
instructions:SetText("|cff00ff00How the Nemesis System Works:|r\n" ..
                     "1. Playerbots you defeat or get slain by become your sworn |cffff0000Rivals|r.\n" ..
                     "2. Rivals will dynamically scale and |cffff0000invade|r you (Dark Souls style) in outdoor zones.\n" ..
                     "3. Every win increases your victories, while defeats raise their |cffff0000Nemesis Rank|r (up to Rank 5).\n" ..
                     "4. Higher rank rivals deal more damage, take less damage, and whisper AI-generated threats!\n" ..
                     "5. Click |cff00ff00Incite Hunt|r to force a rival to spawn nearby immediately.")

-- Update UI Panels
local rivalButtons = {}

local function SelectRival(idx)
    selectedRivalIdx = idx
    for i, btn in ipairs(rivalButtons) do
        if i == idx then
            btn:LockHighlight()
        else
            btn:UnlockHighlight()
        end
    end
    
    local r = rivalsList[idx]
    if r then
        local name, level, raceId, classId, victories, defeats, rank = unpack(r)
        local raceName = RACES[raceId] or "Unknown"
        local className = CLASSES[classId] or "Class"
        local rankName = RANK_TITLES[rank] or "Neutral"
        local color = RANK_COLORS[rank] or "|cffffffff"
        
        detailName:SetText(name)
        detailInfo:SetText(string.format("Level %d %s %s\n%sRank %d: %s|r", level, raceName, className, color, rank, rankName))
        detailStats:SetText(string.format("|cff00ff00Your Victories:|r %d\n|cffff0000Rival Victories:|r %d", defeats, victories))
        huntBtn:Show()
    else
        detailName:SetText("Select a rival from the list")
        detailInfo:SetText("")
        detailStats:SetText("")
        huntBtn:Hide()
    end
end

local function UpdateUI()
    -- Hide existing list buttons
    for _, btn in ipairs(rivalButtons) do
        btn:Hide()
    end
    
    local yOffset = 0
    for i, r in ipairs(rivalsList) do
        local name, level, raceId, classId, victories, defeats, rank = unpack(r)
        local className = CLASSES[classId] or "Class"
        local color = RANK_COLORS[rank] or "|cffffffff"
        
        local btn = rivalButtons[i]
        if not btn then
            btn = CreateFrame("Button", nil, scrollChild)
            btn:SetSize(230, 36)
            btn:SetBackdrop({
                bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                tile = true, tileSize = 16, edgeSize = 8,
                insets = { left = 2, right = 2, top = 2, bottom = 2 }
            })
            btn:SetBackdropColor(0.1, 0.1, 0.12, 0.5)
            btn:SetBackdropBorderColor(0.3, 0.3, 0.35, 0.5)
            
            -- Highlight texture
            local hl = btn:CreateTexture()
            hl:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
            hl:SetBlendMode("ADD")
            hl:SetAllPoints(btn)
            btn:SetHighlightTexture(hl)
            
            btn.nameText = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            btn.nameText:SetPoint("TOPLEFT", 10, -4)
            
            btn.infoText = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            btn.infoText:SetPoint("BOTTOMLEFT", 10, 4)
            
            btn:SetScript("OnClick", function() SelectRival(i) end)
            rivalButtons[i] = btn
        end
        
        btn:SetPoint("TOPLEFT", 5, -yOffset)
        btn.nameText:SetText(color .. name .. "|r")
        btn.infoText:SetText(string.format("Lvl %d %s (Rank %d)", level, className, rank))
        btn:Show()
        
        yOffset = yOffset + 40
    end
    
    scrollChild:SetSize(246, math.max(310, yOffset))
    
    -- Auto-select first or keep selection
    if #rivalsList > 0 then
        if not selectedRivalIdx or selectedRivalIdx > #rivalsList then
            SelectRival(1)
        else
            SelectRival(selectedRivalIdx)
        end
    else
        SelectRival(nil)
    end
end

-- Button click trigger Hunt command
huntBtn:SetScript("OnClick", function()
    if selectedRivalIdx then
        local r = rivalsList[selectedRivalIdx]
        if r then
            -- Send RequestHunt addon message to trigger immediate invasion
            SendAddonMessage("NemesisSystem", "RequestHunt", "WHISPER", UnitName("player"))
            DEFAULT_CHAT_FRAME:AddMessage("|cffff0000[Nemesis]: Invoking hunt for rival " .. r[1] .. "... prepare yourself!|r")
            frame:Hide()
        end
    end
end)

-- Network/Addon Msg Event Register
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("PLAYER_LOGIN")

eventFrame:SetScript("OnEvent", function(self, event, prefix, msg, channel, sender)
    if event == "PLAYER_LOGIN" then
        RegisterAddonMessagePrefix(ADDON_PREFIX)
    elseif event == "CHAT_MSG_ADDON" and prefix == ADDON_PREFIX then
        if msg:find("^Sync:") then
            -- Format: Sync:Name,Level,Race,Class,Wins,Losses,Rank|Name,Level...
            rivalsList = {}
            local data = msg:sub(6)
            if data and data ~= "" then
                for entry in string.gmatch(data, "([^|]+)") do
                    local name, level, raceId, classId, victories, defeats, rank = string.match(entry, "([^,]+),([^,]+),([^,]+),([^,]+),([^,]+),([^,]+),([^,]+)")
                    if name then
                        table.insert(rivalsList, {
                            name,
                            tonumber(level) or 1,
                            tonumber(raceId) or 1,
                            tonumber(classId) or 1,
                            tonumber(victories) or 0,
                            tonumber(defeats) or 0,
                            tonumber(rank) or 0
                        })
                    end
                end
            end
            UpdateUI()
        end
    end
end)

-- Slash Commands
SLASH_NEMESIS1 = "/nemesis"
SLASH_NEMESIS2 = "/rivals"
SlashCmdList["NEMESIS"] = function(msg)
    if NemesisFrame:IsShown() then
        NemesisFrame:Hide()
    else
        NemesisFrame:Show()
        -- Ask server for updated rivals list
        SendAddonMessage(ADDON_PREFIX, "RequestSync", "WHISPER", UnitName("player"))
    end
end

DEFAULT_CHAT_FRAME:AddMessage("|cff00ffff[NemesisSystem]: Addon loaded. Type /nemesis or /rivals to open active rivals dashboard.|r")
