-- Custom WoW Client Addon: Wanted Board GUI
-- Author: Antigravity

local ADDON_PREFIX = "WantedBoard"

local RACES = {
    [1] = "Human", [2] = "Orc", [3] = "Dwarf", [4] = "Night Elf",
    [5] = "Undead", [6] = "Tauren", [7] = "Gnome", [8] = "Troll",
    [10] = "Blood Elf", [11] = "Draenei"
}

local CLASSES = {
    [1] = "Warrior", [2] = "Paladin", [3] = "Hunter", [4] = "Rogue",
    [5] = "Priest", [6] = "Death Knight", [7] = "Shaman", [8] = "Mage",
    [9] = "Warlock", [11] = "Druid"
}

local CLASS_TEX_COORDS = {
    ["Warrior"]      = {0, 0.25, 0, 0.25},
    ["Mage"]         = {0.25, 0.5, 0, 0.25},
    ["Rogue"]        = {0.5, 0.75, 0, 0.25},
    ["Druid"]        = {0.75, 1, 0, 0.25},
    ["Hunter"]       = {0, 0.25, 0.25, 0.5},
    ["Shaman"]       = {0.25, 0.5, 0.25, 0.5},
    ["Priest"]       = {0.5, 0.75, 0.25, 0.5},
    ["Warlock"]      = {0.75, 1, 0.25, 0.5},
    ["Paladin"]      = {0, 0.25, 0.5, 0.75},
    ["Death Knight"] = {0.25, 0.5, 0.5, 0.75}
}

local RANK_TITLES = {
    [0] = "Neutral",
    [1] = "Scourge",
    [2] = "Marauder",
    [3] = "Slayer",
    [4] = "Dreadlord",
    [5] = "Grand Inquisitor"
}

local RANK_COLORS = {
    [0] = "|cff808080", -- Grey
    [1] = "|cff00ff00", -- Green
    [2] = "|cff00ffff", -- Cyan
    [3] = "|cff9370db", -- Purple
    [4] = "|cffffa500", -- Orange
    [5] = "|cffff0000"  -- Red
}

-- Utility function to split string
local function split(str, sep)
    local result = {}
    local from = 1
    local delim_from, delim_to = string.find(str, sep, from)
    while delim_from do
        table.insert(result, string.sub(str, from, delim_from - 1))
        from = delim_to + 1
        delim_from, delim_to = string.find(str, sep, from)
    end
    table.insert(result, string.sub(str, from))
    return result
end

-- Format Money helper
local function FormatMoneyString(copper)
    local copperVal = tonumber(copper) or 0
    local gold = math.floor(copperVal / 10000)
    local silver = math.floor((copperVal % 10000) / 100)
    local cop = copperVal % 100
    
    local parts = {}
    if gold > 0 then
        table.insert(parts, string.format("|cffffd700%dg|r", gold))
    end
    if silver > 0 or gold > 0 then
        table.insert(parts, string.format("|cffc7c7c7%ds|r", silver))
    end
    table.insert(parts, string.format("|cffeda55f%dc|r", cop))
    
    return table.concat(parts, " ")
end

-- Create Main Board UI
local frame = CreateFrame("Frame", "WantedBoardFrame", UIParent)
frame:SetSize(850, 560)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:Hide()

frame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 16, edgeSize = 20,
    insets = { left = 5, right = 5, top = 5, bottom = 5 }
})
frame:SetBackdropColor(0.06, 0.06, 0.08, 0.95)
frame:SetBackdropBorderColor(0.25, 0.25, 0.3, 0.9)

-- Title
local titleText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
titleText:SetPoint("TOP", 0, -18)
titleText:SetText("|cffffd700WANTED BOARD - CONTRACTS & RIVALS|r")

-- Close Button
local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -6, -6)

---------------------------------------------------------
-- LEFT PANEL: ACTIVE CONTRACTS
---------------------------------------------------------
local leftPanel = CreateFrame("Frame", nil, frame)
leftPanel:SetSize(400, 480)
leftPanel:SetPoint("TOPLEFT", 20, -50)

local leftTitle = leftPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
leftTitle:SetPoint("TOP", 0, 0)
leftTitle:SetText("ACTIVE BOUNTY CONTRACTS")

-- 1. PvP Poster
local pvpPoster = CreateFrame("Frame", nil, leftPanel)
pvpPoster:SetSize(380, 215)
pvpPoster:SetPoint("TOP", 0, -20)
pvpPoster:SetBackdrop({
    bgFile = "Interface\\AchievementFrame\\UI-Achievement-Parchment-Horizontal",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 256, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
pvpPoster:SetBackdropColor(0.95, 0.9, 0.82, 1.0)
pvpPoster:SetBackdropBorderColor(0.4, 0.3, 0.2, 0.6)

local pvpHeader = pvpPoster:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
pvpHeader:SetPoint("TOP", 0, -8)
pvpHeader:SetText("|cff8b0000WANTED: ASSASSINATION|r")

local pvpClassIcon = pvpPoster:CreateTexture(nil, "OVERLAY")
pvpClassIcon:SetSize(48, 48)
pvpClassIcon:SetPoint("TOPLEFT", 15, -35)
pvpClassIcon:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")

local pvpDetails = pvpPoster:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
pvpDetails:SetPoint("TOPLEFT", 75, -35)
pvpDetails:SetJustifyH("LEFT")
pvpDetails:SetText("No target bot available.")

local pvpRewardLabel = pvpPoster:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
pvpRewardLabel:SetPoint("BOTTOMLEFT", 15, 60)
pvpRewardLabel:SetText("|cff2f4f4fContract Rewards:|r")

local pvpRewardGold = pvpPoster:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
pvpRewardGold:SetPoint("BOTTOMLEFT", 15, 40)
pvpRewardGold:SetText("0g 0s 0c")

local pvpOrbIcon = pvpPoster:CreateTexture(nil, "OVERLAY")
pvpOrbIcon:SetSize(28, 28)
pvpOrbIcon:SetPoint("BOTTOMLEFT", 160, 36)

local pvpOrbCount = pvpPoster:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
pvpOrbCount:SetPoint("LEFT", pvpOrbIcon, "RIGHT", 4, 0)
pvpOrbCount:SetText("x0")

local pvpActionBtn = CreateFrame("Button", nil, pvpPoster, "UIPanelButtonTemplate")
pvpActionBtn:SetSize(120, 24)
pvpActionBtn:SetPoint("BOTTOMRIGHT", -15, 12)
pvpActionBtn:SetText("Accept")

-- 2. PvE Poster
local pvePoster = CreateFrame("Frame", nil, leftPanel)
pvePoster:SetSize(380, 215)
pvePoster:SetPoint("TOP", 0, -250)
pvePoster:SetBackdrop({
    bgFile = "Interface\\AchievementFrame\\UI-Achievement-Parchment-Horizontal",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 256, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
pvePoster:SetBackdropColor(0.95, 0.9, 0.82, 1.0)
pvePoster:SetBackdropBorderColor(0.4, 0.3, 0.2, 0.6)

local pveHeader = pvePoster:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
pveHeader:SetPoint("TOP", 0, -8)
pveHeader:SetText("|cff1e4d2bWANTED: MONSTER HUNT|r")

local pveSkullIcon = pvePoster:CreateTexture(nil, "OVERLAY")
pveSkullIcon:SetSize(48, 48)
pveSkullIcon:SetPoint("TOPLEFT", 15, -35)
pveSkullIcon:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")

local pveDetails = pvePoster:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
pveDetails:SetPoint("TOPLEFT", 75, -35)
pveDetails:SetJustifyH("LEFT")
pveDetails:SetText("No monster contract available.")

local pveRewardLabel = pvePoster:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
pveRewardLabel:SetPoint("BOTTOMLEFT", 15, 60)
pveRewardLabel:SetText("|cff2f4f4fContract Rewards:|r")

local pveRewardGold = pvePoster:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
pveRewardGold:SetPoint("BOTTOMLEFT", 15, 40)
pveRewardGold:SetText("0g 0s 0c")

local pveOrbIcon = pvePoster:CreateTexture(nil, "OVERLAY")
pveOrbIcon:SetSize(28, 28)
pveOrbIcon:SetPoint("BOTTOMLEFT", 160, 36)

local pveOrbCount = pvePoster:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
pveOrbCount:SetPoint("LEFT", pveOrbIcon, "RIGHT", 4, 0)
pveOrbCount:SetText("x0")

local pveActionBtn = CreateFrame("Button", nil, pvePoster, "UIPanelButtonTemplate")
pveActionBtn:SetSize(120, 24)
pveActionBtn:SetPoint("BOTTOMRIGHT", -15, 12)
pveActionBtn:SetText("Accept")


---------------------------------------------------------
-- RIGHT PANEL: MOST WANTED RIVALS
---------------------------------------------------------
local rightPanel = CreateFrame("Frame", nil, frame)
rightPanel:SetSize(395, 480)
rightPanel:SetPoint("TOPRIGHT", -20, -50)

local rightTitle = rightPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
rightTitle:SetPoint("TOP", 0, 0)
rightTitle:SetText("MOST WANTED PLAYERBOT RIVALS")

local scrollFrame = CreateFrame("ScrollFrame", "WantedBoardRivalScroll", rightPanel, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", 5, -20)
scrollFrame:SetPoint("BOTTOMRIGHT", -24, 10)

local scrollChild = CreateFrame("Frame", nil, scrollFrame)
scrollChild:SetSize(360, 440)
scrollFrame:SetScrollChild(scrollChild)

-- Sub-details local targets
local currentPvPTargetGuid = 0
local currentPvPTargetActive = false
local currentPvETargetEntry = 0
local currentPvETargetActive = false

-- Action Buttons Listeners
pvpActionBtn:SetScript("OnClick", function()
    if currentPvPTargetActive then
        SendAddonMessage(ADDON_PREFIX, "AbandonPvP", "WHISPER", UnitName("player"))
    else
        if currentPvPTargetGuid ~= 0 then
            SendAddonMessage(ADDON_PREFIX, "AcceptPvP:" .. currentPvPTargetGuid, "WHISPER", UnitName("player"))
        end
    end
end)

pveActionBtn:SetScript("OnClick", function()
    if currentPvETargetActive then
        SendAddonMessage(ADDON_PREFIX, "AbandonPvE", "WHISPER", UnitName("player"))
    else
        if currentPvETargetEntry ~= 0 then
            SendAddonMessage(ADDON_PREFIX, "AcceptPvE:" .. currentPvETargetEntry, "WHISPER", UnitName("player"))
        end
    end
end)

-- Rival rows pool
local rivalRows = {}

local function CreateRivalRow(i)
    local row = CreateFrame("Frame", nil, scrollChild)
    row:SetSize(350, 78)
    row:SetPoint("TOPLEFT", 5, -(i-1)*82)
    row:SetBackdrop({
        bgFile = "Interface\\AchievementFrame\\UI-Achievement-Parchment-Horizontal",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 256, edgeSize = 10,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    row:SetBackdropColor(0.9, 0.88, 0.84, 0.9)
    row:SetBackdropBorderColor(0.4, 0.35, 0.3, 0.5)
    
    local classIcon = row:CreateTexture(nil, "OVERLAY")
    classIcon:SetSize(32, 32)
    classIcon:SetPoint("LEFT", 12, 0)
    classIcon:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
    row.classIcon = classIcon
    
    local textDetails = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    textDetails:SetPoint("TOPLEFT", 52, -8)
    textDetails:SetJustifyH("LEFT")
    textDetails:SetSpacing(2)
    row.textDetails = textDetails
    
    local bountyText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    bountyText:SetPoint("BOTTOMLEFT", 52, 8)
    bountyText:SetTextColor(0.9, 0.1, 0.1) -- red
    bountyText:SetText("")
    row.bountyText = bountyText
    
    local huntBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    huntBtn:SetSize(72, 22)
    huntBtn:SetPoint("RIGHT", -12, 0)
    huntBtn:SetText("Incite Hunt")
    row.huntBtn = huntBtn
    
    row:Hide()
    return row
end

-- Update Main UI
local function UpdateUI(pvpData, pveData, rivalData, rivalsListStr)
    -- 1. Update PvP Poster
    -- Format: active_flag#name#level#race#class#reward_copper#reward_orb_id#reward_orb_count#zoneName#status#target_guid
    local pparts = split(pvpData, "#")
    if #pparts >= 10 then
        local active = pparts[1] == "1"
        local name = pparts[2]
        local lvl = tonumber(pparts[3]) or 1
        local raceId = tonumber(pparts[4]) or 1
        local classId = tonumber(pparts[5]) or 1
        local reward = tonumber(pparts[6]) or 0
        local orbId = tonumber(pparts[7]) or 0
        local orbCount = tonumber(pparts[8]) or 0
        local zone = pparts[9]
        local status = pparts[10]
        currentPvPTargetGuid = tonumber(pparts[11]) or 0
        currentPvPTargetActive = active
        
        local raceName = RACES[raceId] or "Human"
        local className = CLASSES[classId] or "Warrior"
        
        -- Set Class Icon
        local coords = CLASS_TEX_COORDS[className]
        if coords then
            pvpClassIcon:SetTexCoord(unpack(coords))
        end
        
        -- Set Text
        local detailsStr = string.format("|cff2f4f4fTarget:|r |cffff0000%s|r (Lvl %d %s)\n|cff2f4f4fClass:|r %s\n|cff2f4f4fLast Seen:|r |cff8b4513%s|r\n|cff2f4f4fStatus:|r %s",
            name, lvl, raceName, className, zone, status == "Online" and "|cff00ff00Online|r" or "|cff808080Offline|r")
        pvpDetails:SetText(detailsStr)
        
        -- Rewards
        pvpRewardGold:SetText(FormatMoneyString(reward))
        
        if orbId > 0 and orbCount > 0 then
            pvpOrbIcon:SetTexture(GetItemIcon(orbId))
            pvpOrbCount:SetText("x" .. orbCount)
            pvpOrbIcon:Show()
            pvpOrbCount:Show()
        else
            pvpOrbIcon:Hide()
            pvpOrbCount:Hide()
        end
        
        -- Button
        if active then
            pvpActionBtn:SetText("Abandon")
        else
            pvpActionBtn:SetText("Accept")
        end
        pvpActionBtn:Show()
    else
        pvpDetails:SetText("No contracts available.")
        pvpRewardGold:SetText("0g 0s 0c")
        pvpOrbIcon:Hide()
        pvpOrbCount:Hide()
        pvpActionBtn:Hide()
    end
    
    -- 2. Update PvE Poster
    -- Format: active_flag#entry#name#reward_copper#reward_orb_id#reward_orb_count#zoneName
    local eparts = split(pveData, "#")
    if #eparts >= 7 then
        local active = eparts[1] == "1"
        currentPvETargetEntry = tonumber(eparts[2]) or 0
        local rawName = eparts[3]
        local reward = tonumber(eparts[4]) or 0
        local orbId = tonumber(eparts[5]) or 0
        local orbCount = tonumber(eparts[6]) or 0
        local zone = eparts[7]
        currentPvETargetActive = active
        
        pveDetails:SetText(string.format("|cff2f4f4fTarget:|r |cff006400%s|r\n|cff2f4f4fRegion:|r |cff8b4513%s|r", rawName, zone))
        
        -- Rewards
        pveRewardGold:SetText(FormatMoneyString(reward))
        
        if orbId > 0 and orbCount > 0 then
            pveOrbIcon:SetTexture(GetItemIcon(orbId))
            pveOrbCount:SetText("x" .. orbCount)
            pveOrbIcon:Show()
            pveOrbCount:Show()
        else
            pveOrbIcon:Hide()
            pveOrbCount:Hide()
        end
        
        -- Button
        if active then
            pveActionBtn:SetText("Abandon")
        else
            pveActionBtn:SetText("Accept")
        end
        pveActionBtn:Show()
    else
        pveDetails:SetText("No contracts available.")
        pveRewardGold:SetText("0g 0s 0c")
        pveOrbIcon:Hide()
        pveOrbCount:Hide()
        pveActionBtn:Hide()
    end
    
    -- 3. Update Rivals List
    -- Hide old rows
    for _, row in ipairs(rivalRows) do
        row:Hide()
    end
    
    if rivalsListStr and rivalsListStr ~= "None" and rivalsListStr ~= "" then
        local entries = split(rivalsListStr, ";")
        local yOffset = 0
        for i, entry in ipairs(entries) do
            -- Format: name#level#race#class#rank#victories#defeats#bounty_amount#zoneName#status#target_guid
            local rparts = split(entry, "#")
            if #rparts >= 11 then
                local name = rparts[1]
                local lvl = tonumber(rparts[2]) or 1
                local raceId = tonumber(rparts[3]) or 1
                local classId = tonumber(rparts[4]) or 1
                local rank = tonumber(rparts[5]) or 0
                local wins = tonumber(rparts[6]) or 0
                local losses = tonumber(rparts[7]) or 0
                local bounty = tonumber(rparts[8]) or 0
                local zone = rparts[9]
                local status = rparts[10]
                local rguid = tonumber(rparts[11]) or 0
                
                local raceName = RACES[raceId] or "Human"
                local className = CLASSES[classId] or "Warrior"
                local rankTitle = RANK_TITLES[rank] or "Neutral"
                local colorPrefix = RANK_COLORS[rank] or "|cffffffff"
                
                local row = rivalRows[i]
                if not row then
                    row = CreateRivalRow(i)
                    rivalRows[i] = row
                end
                
                -- Set Class Icon
                local coords = CLASS_TEX_COORDS[className]
                if coords then
                    row.classIcon:SetTexCoord(unpack(coords))
                end
                
                -- Details text
                local statusColor = (status == "Online") and "|cff00ff00Online|r" or "|cff808080Offline|r"
                local detailStr = string.format("%s%s|r (Lvl %d %s)\nRank: %s%s|r | Wins: %d | Losses: %d\nLast Seen: %s (%s)",
                    colorPrefix, name, lvl, className, colorPrefix, rankTitle, wins, losses, zone, statusColor)
                row.textDetails:SetText(detailStr)
                
                -- Bounty
                if bounty > 0 then
                    row.bountyText:SetText("Bounty on you: " .. FormatMoneyString(bounty))
                else
                    row.bountyText:SetText("")
                end
                
                -- Hunt Button (Enable only if it is the primary/sworn rival - typically first row is highest rank)
                -- For simplicity, let's allow Incite Hunt on any rival that is online, or just the top rank one.
                -- Let's make it so you can Incite Hunt on the top ranked one (i == 1) or any if they are online.
                if i == 1 then
                    row.huntBtn:SetScript("OnClick", function()
                        SendAddonMessage("NemesisSystem", "RequestHunt", "WHISPER", UnitName("player"))
                        DEFAULT_CHAT_FRAME:AddMessage("|cffff0000[Nemesis]: Invoking hunt for rival " .. name .. "... prepare yourself!|r")
                        frame:Hide()
                    end)
                    row.huntBtn:Show()
                else
                    row.huntBtn:Hide()
                end
                
                row:Show()
                yOffset = yOffset + 82
            end
        end
        scrollChild:SetSize(360, math.max(440, yOffset))
    else
        -- Show "No rivals" label or similar
    end
end

-- Network Message Listener
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("PLAYER_LOGIN")

eventFrame:SetScript("OnEvent", function(self, event, prefix, msg, channel, sender)
    if event == "PLAYER_LOGIN" then
        RegisterAddonMessagePrefix(ADDON_PREFIX)
    elseif event == "CHAT_MSG_ADDON" and prefix == ADDON_PREFIX then
        if msg:find("^Sync:") then
            -- Format: Sync:pvpSync|pveSync|rivalSync|listSyncStr
            local data = msg:sub(6)
            local sections = split(data, "|")
            if #sections >= 4 then
                UpdateUI(sections[1], sections[2], sections[3], sections[4])
                frame:Show()
            end
        end
    end
end)

-- Slash Command fallback
SLASH_WANTEDBOARD1 = "/wanted"
SLASH_WANTEDBOARD2 = "/wantedboard"
SlashCmdList["WANTEDBOARD"] = function(msg)
    if frame:IsShown() then
        frame:Hide()
    else
        -- Ask server for sync
        SendAddonMessage(ADDON_PREFIX, "RequestSync", "WHISPER", UnitName("player"))
    end
end

DEFAULT_CHAT_FRAME:AddMessage("|cff00ffff[WantedBoard]: Addon loaded. Visit a Wanted Board in Stormwind/Orgrimmar or type /wanted to open.|r")
