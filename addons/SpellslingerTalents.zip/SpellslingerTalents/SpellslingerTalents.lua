-- Custom WoW Client Addon: Spellslinger Talents Frame & Equilibrium Gauge
-- Allows allocating, resetting, and activating subclass talents for Spellslinger (Death Knight).
-- Author: Antigravity

local ADDON_PREFIX = "SpellslingerTalents"
local talentRanks = {}
for i = 1, 42 do talentRanks[i] = 0 end
local totalSpent = 0
local freePoints = 0
local equilibriumVal = 50

-- Talent Definitions (matching server)
local TALENTS = {
    -- Tree 1: Riftcaller
    { id = 1,  tree = 1, row = 1, col = 1, name = "Neural Acceleration", max = 5, desc = "Increases the critical strike chance of your mind-thrown Shadow-Temporal spells by 1/2/3/4/5%." },
    { id = 2,  tree = 1, row = 1, col = 2, name = "Extended Timeline", max = 5, desc = "Increases the duration of your Rapid Senescence and Withering Epoch time-diseases by 2/4/6/8/10 seconds." },
    { id = 3,  tree = 1, row = 2, col = 1, name = "Psychic Backlash", max = 3, desc = "Your basic mind-blasts have a 10/20/30% chance to cause an entropic echo, dealing minor AoE shadow damage equal to 15% of your Spell Power to all targets within 8 yards." },
    { id = 4,  tree = 1, row = 2, col = 2, name = "Quick Trigger Flux", max = 2, desc = "Reduces the global cooldown of your temporal mind curses, rifts, and discharges by 0.15/0.30 seconds." },
    { id = 5,  tree = 1, row = 3, col = 1, name = "Psionic Mirror", max = 1, desc = "Active (60s CD): Materializes a psychic phantom of your past self for 10 seconds. The phantom duplicates your baseline telekinetic throws at a target, dealing 25% of your standard damage.", isActive = true },
    { id = 6,  tree = 1, row = 3, col = 2, name = "Siphon Momentum", max = 3, desc = "Every time your periodic time-diseases deal damage, you have a 2/4/6% chance to instantly generate 2 Runic Power by stealing the target's velocity." },
    { id = 7,  tree = 1, row = 3, col = 3, name = "Temporal Shielding", max = 3, desc = "Permanently converts 10/20/30% of your total Intellect into passive Spell Power." },
    { id = 8,  tree = 1, row = 4, col = 1, name = "Synapse Collapse", max = 2, desc = "Requires Psionic Mirror. When your Psionic Mirror expires or is destroyed, it collapses into a gravity singularity, dealing Shadow-Temporal damage and pulling targets in.", req = 5 },
    { id = 9,  tree = 1, row = 4, col = 2, name = "Chronal Glide", max = 3, desc = "Increases your movement speed by 4/8/12% while you maintain at least 50 Runic Power in your chamber pool." },
    { id = 10, tree = 1, row = 5, col = 1, name = "Tachyon Mind-Barrage", max = 1, desc = "Active (10s CD): Projects a rapid stream of pure tachyon energy from your mind. Ricochets up to 3 targets, dealing heavy damage and forcing diseases to tick 3 times.", isActive = true },
    { id = 11, tree = 1, row = 5, col = 2, name = "Entropy Engine", max = 5, desc = "Increases the damage dealt by your Runic Power spenders (Chamber Discharges) by 2/4/6/8/10%." },
    { id = 12, tree = 1, row = 6, col = 1, name = "Thought-Cylinder", max = 3, desc = "Requires Tachyon Mind-Barrage. Increases the critical strike chance of your Tachyon Mind-Barrage by 3/6/10%. If it crits, increase spell haste by 5% for 6s.", req = 10 },
    { id = 13, tree = 1, row = 6, col = 2, name = "Cognitive Trigger", max = 2, desc = "Your Runic Power spenders deal 5/10% additional damage if the target is afflicted by both time-diseases." },
    { id = 14, tree = 1, row = 7, col = 1, name = "Grand Shatter", max = 1, desc = "Capstone Active (2.5m CD): Unleashes a channeled psychic temporal rift over 3s, dealing heavy damage and detonating diseases. Mirrors duplicate this channel.", isActive = true },

    -- Tree 2: Aethershaper
    { id = 15, tree = 2, row = 1, col = 1, name = "Synaptic Frost", max = 5, desc = "Increases the critical strike chance of your mind-thrown Frost spells by 1/2/3/4/5%." },
    { id = 16, tree = 2, row = 1, col = 2, name = "Cerebral Ignition", max = 5, desc = "Your Fire spells leave an entropic brain-burn debuff, dealing an additional 6/12/18/24/30% of damage over 6 seconds." },
    { id = 17, tree = 2, row = 2, col = 1, name = "Thermal Shock", max = 2, desc = "Requires Synaptic Frost. Your critical hits with Frost spells have a 50/100% chance to flash-freeze and stun the target for 2 seconds.", req = 15 },
    { id = 18, tree = 2, row = 2, col = 2, name = "Combustion Ripples", max = 3, desc = "Requires Cerebral Ignition. Your Fire critical strikes cause a mental shockwave, splashing 20/40/60% damage to nearby enemies.", req = 16 },
    { id = 19, tree = 2, row = 3, col = 1, name = "Thermal Equilibrium", max = 1, desc = "Passive: Unlocks the Equilibrium Gauge. Frost spells push it left; Fire spells push it right. Center Equilibrium Zone increases spell damage by 15%." },
    { id = 20, tree = 2, row = 3, col = 2, name = "Psychic Insulation", max = 3, desc = "Reduces the channel time of Active Reload by 1/2/3s and reduces all magical damage taken during it by 10/20/30%." },
    { id = 21, tree = 2, row = 3, col = 3, name = "Kinetic Extension", max = 2, desc = "Increases the maximum range of your mental element projections by 3/6 yards." },
    { id = 22, tree = 2, row = 4, col = 1, name = "Perfect Balance", max = 1, desc = "Requires Thermal Equilibrium. Widens the visual center 'Equilibrium Zone' framework on your UI gauge by 25%.", req = 19 },
    { id = 23, tree = 2, row = 4, col = 2, name = "Sub-Atomic Piercing", max = 3, desc = "Your mental element projections ignore 4/8/12% of the target's magical resistances." },
    { id = 24, tree = 2, row = 5, col = 1, name = "Mind-Freeze Nova", max = 1, desc = "Active (30s CD): Projects a wave of sub-zero atomic stagnation, dealing Frost damage, rooting targets, and pulling gauge 50% left.", isActive = true },
    { id = 25, tree = 2, row = 5, col = 2, name = "Thermodynamic Collapse", max = 3, desc = "Your Fire spells deal 4/8/12% more damage if the target is slowed, rooted, or frozen by your Frost spells." },
    { id = 26, tree = 2, row = 6, col = 1, name = "Hypothermic Shatter", max = 3, desc = "Requires Mind-Freeze Nova. Striking rooted targets with Fire spells breaks root and deals catastrophic Spellstrike damage (120% SP).", req = 24 },
    { id = 27, tree = 2, row = 6, col = 2, name = "Volatile Synapses", max = 2, desc = "Spending maximum Runic Power on a single discharge has a 15/30% chance to reset Fire cooldowns." },
    { id = 28, tree = 2, row = 7, col = 1, name = "Psychic Melt", max = 1, desc = "Capstone Active (3m CD): Locks gauge in the center zone for 15s. Runes incur no CD on use and spellcasting speed is increased by 30%.", isActive = true },

    -- Tree 3: Voidbinder
    { id = 29, tree = 3, row = 1, col = 1, name = "Mental Fortitude", max = 5, desc = "Increases the raw healing output baseline of your mind-cast temporal spells by 1/2/3/4/5%." },
    { id = 30, tree = 3, row = 1, col = 2, name = "Echoing Mending", max = 5, desc = "Your temporal single-target heals leave a psychic echo, healing for 6/12/18/24/30% of the initial value 3 seconds later." },
    { id = 31, tree = 3, row = 2, col = 1, name = "Stasis Shell", max = 3, desc = "Allies healed by your mental time rifts gain a protective shell, increasing physical armor by 4/8/12% for 6 seconds." },
    { id = 32, tree = 3, row = 2, col = 2, name = "Cognitive Reflex", max = 3, desc = "Reduces the cast time of your primary single-target temporal mends by 0.1/0.2/0.3 seconds." },
    { id = 33, tree = 3, row = 3, col = 1, name = "Fate Intercept", max = 1, desc = "Active (45s CD): Redirects 20% of damage sustained by an ally directly into your Runic Power bar for 15 seconds.", isActive = true },
    { id = 34, tree = 3, row = 3, col = 2, name = "Siphon Entropy", max = 3, desc = "Every time your Echoing Mending triggers, you have a 4/8/12% chance to instantly refresh and reset 1 spent Frost Rune." },
    { id = 35, tree = 3, row = 3, col = 3, name = "Temporal Distortion", max = 2, desc = "Increases the maximum range of your mental healing projections and shields by 3/6 yards." },
    { id = 36, tree = 3, row = 4, col = 1, name = "Mass Paradox", max = 2, desc = "Requires Fate Intercept. Allows your Fate Intercept link to be active on up to 2 friendly targets simultaneously.", req = 33 },
    { id = 37, tree = 3, row = 4, col = 2, name = "Splintered Fate", max = 3, desc = "When your shielding arrays expire or break, they grant 3 nearby allies a shield equal to 10/20/30% of the original." },
    { id = 38, tree = 3, row = 5, col = 1, name = "Timeline Reversal", max = 1, desc = "Active (20s CD): Anchors target ally's health profile for 4 seconds. Erases all damage sustained during that window and heals them for it.", isActive = true },
    { id = 39, tree = 3, row = 5, col = 2, name = "Cerebral Clarity", max = 3, desc = "Your mind-cast temporal healing abilities ignore 10/20/30% of any active healing-reduction debuffs." },
    { id = 40, tree = 3, row = 6, col = 1, name = "Cylinder of Fate", max = 3, desc = "Requires Timeline Reversal. Increases crit healing chance of Timeline Reversal by 3/6/10%. If it crits, target gets 10% damage reduction for 6s.", req = 38 },
    { id = 41, tree = 3, row = 6, col = 2, name = "Borrowed Longevity", max = 3, desc = "Whenever a party/raid member within 40 yards scores a critical strike, instantly grant you 3/6/10 Runic Power." },
    { id = 42, tree = 3, row = 7, col = 1, name = "The Hourglass Sanctuary", max = 1, desc = "Capstone Active (3m CD): Projects a 15-yard temporal dome for 6s. Allies inside take 50% reduced damage. Casted heals duplicate to all allies inside.", isActive = true }
}

-- Icons corresponding to Spellslinger talents
local ICONS = {
    [1]  = "Spell_Shadow_DeadlyPsychicShock",
    [2]  = "Spell_Holy_BorrowTime",
    [3]  = "Spell_Shadow_PsychicScream",
    [4]  = "Spell_Arcane_StudentOfMagic",
    [5]  = "Spell_Shadow_AntiShadow",
    [6]  = "Ability_Creature_Disease_02",
    [7]  = "Spell_Holy_PowerWordShield",
    [8]  = "Spell_Shadow_AnimateDead",
    [9]  = "Ability_Rogue_QuickRecovery",
    [10] = "Spell_Arcane_StarFire",
    [11] = "Spell_Shadow_GrimWard",
    [12] = "Spell_Arcane_MindPreservation",
    [13] = "Ability_Hunter_GildedChevron",
    [14] = "Spell_Shadow_BlackPlague",

    [15] = "Spell_Frost_ChilledInBone",
    [16] = "Spell_Fire_Incinerate",
    [17] = "Spell_Frost_FreezingBreath",
    [18] = "Spell_Fire_SelfDestruct",
    [19] = "Spell_Arcane_ManaTap",
    [20] = "Spell_Frost_WizardMark",
    [21] = "Spell_Arcane_StudentOfMagic",
    [22] = "Spell_Arcane_PortalDarnassus",
    [23] = "Spell_Fire_Fireball",
    [24] = "Spell_Frost_FrostNova",
    [25] = "Spell_Fire_SoulBurn",
    [26] = "Spell_Frost_IceShard",
    [27] = "Spell_Fire_LavaBurst",
    [28] = "Spell_Fire_Burnout",

    [29] = "Spell_Holy_WordFortitude",
    [30] = "Spell_Holy_Renew",
    [31] = "Spell_Holy_DevotionAura",
    [32] = "Spell_Holy_FlashHeal",
    [33] = "Spell_Holy_SpellWard",
    [34] = "Spell_Holy_Purify",
    [35] = "Spell_Holy_PhaseShift",
    [36] = "Spell_Holy_GreaterBlessingOfSalvation",
    [37] = "Spell_Holy_PowerWordShield",
    [38] = "Spell_Holy_Chastise",
    [39] = "Spell_Holy_LayOnHands",
    [40] = "Spell_Holy_Restoration",
    [41] = "Spell_Holy_EluneGrace",
    [42] = "Spell_Holy_DivineIntervention"
}

-- Create the main UI frame
local frame = CreateFrame("Frame", "SpellslingerTalentFrame", UIParent)
frame:SetSize(760, 600)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:Hide()

frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 }
})

-- Header Title
local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOP", 0, -18)
title:SetText("Spellslinger Subclass Talents")

-- Points Label
local pointsText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
pointsText:SetPoint("TOPLEFT", 25, -20)
pointsText:SetText("Points Available: 0")

-- Close Button
local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -8, -8)

-- Tab Headers & Column Frames
local headers = { "Riftcaller (Space-Time)", "Aethershaper (Thermal)", "Voidbinder (Aether Mend)" }
local columns = {}

for colIdx = 1, 3 do
    local col = CreateFrame("Frame", nil, frame)
    col:SetSize(235, 485)
    col:SetPoint("TOPLEFT", 18 + (colIdx - 1) * 243, -50)
    
    col:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    col:SetBackdropColor(0.02, 0.02, 0.05, 0.85) -- Sleek dark twilight-blue shade
    
    local colTitle = col:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    colTitle:SetPoint("TOP", 0, -10)
    colTitle:SetText(headers[colIdx])
    
    columns[colIdx] = col
end

-- Render all talent buttons
local buttons = {}
for _, t in ipairs(TALENTS) do
    local parent = columns[t.tree]
    local btn = CreateFrame("Button", "SpellslingerTalentBtn_" .. t.id, parent)
    btn:SetSize(42, 42)
    -- Calculate coordinates inside column frame
    local xOffset = 25 + (t.col - 1) * 70
    local yOffset = -40 - (t.row - 1) * 62
    btn:SetPoint("TOPLEFT", xOffset, yOffset)
    
    -- Icon texture
    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetAllPoints()
    local iconName = ICONS[t.id] or "Ability_Hunter_MasterMarksman"
    icon:SetTexture("Interface\\Icons\\" .. iconName)
    btn.icon = icon
    
    -- Border frame (color themes for trees)
    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetSize(60, 60)
    border:SetPoint("CENTER", 0, 0)
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    if t.tree == 1 then
        border:SetVertexColor(0.6, 0.2, 0.9) -- Indigo / Twilight Purple
    elseif t.tree == 2 then
        border:SetVertexColor(1.0, 0.4, 0.1) -- Fire / Frost Orange-Cyan
    else
        border:SetVertexColor(0.1, 0.7, 0.9) -- Radiant Cyan / Healing Blue
    end
    btn.border = border
    
    -- Counter label (ranks)
    local count = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    count:SetPoint("BOTTOMRIGHT", 2, -2)
    count:SetText("0/" .. t.max)
    btn.count = count
    
    -- Mouse interactions
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(t.name, 1, 1, 1)
        if t.isActive then
            GameTooltip:AddLine("Active Ability (Finisher/CD)", 0.4, 0.9, 1.0)
        else
            GameTooltip:AddLine("Passive Subclass Talent", 0.7, 0.7, 0.7)
        end
        GameTooltip:AddLine("Rank: " .. talentRanks[t.id] .. "/" .. t.max, 0, 1, 0)
        GameTooltip:AddLine(t.desc, 0.8, 0.8, 0.8, true)
        
        if t.isActive and talentRanks[t.id] > 0 then
            GameTooltip:AddLine("\n|cff00ff55Click to Cast Ability (Triggers server spell)|r")
        end
        
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    
    btn:SetScript("OnClick", function(self, button)
        if t.isActive and talentRanks[t.id] > 0 then
            SendAddonMessage(ADDON_PREFIX, "UseActive:" .. t.id, "WHISPER", UnitName("player"))
        else
            SendAddonMessage(ADDON_PREFIX, "Learn:" .. t.id, "WHISPER", UnitName("player"))
        end
    end)
    
    buttons[t.id] = btn
end

-- Reset Button
local resetBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
resetBtn:SetSize(120, 24)
resetBtn:SetPoint("BOTTOMLEFT", 25, 20)
resetBtn:SetText("Reset Talents")
resetBtn:SetScript("OnClick", function()
    PlaySound("igMainMenuOption")
    SendAddonMessage(ADDON_PREFIX, "Reset", "WHISPER", UnitName("player"))
end)

-- Help Label
local helpText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
helpText:SetPoint("BOTTOMRIGHT", -25, 24)
helpText:SetText("Commands: /talents or /spellslinger")


----------------------------------------------------
-- EQUILIBRIUM GAUGE HUD (Aethershaper HUD)
----------------------------------------------------
local hud = CreateFrame("Frame", "SpellslingerEquilibriumFrame", UIParent)
hud:SetSize(220, 50)
hud:SetPoint("BOTTOM", 0, 250)
hud:SetMovable(true)
hud:EnableMouse(true)
hud:RegisterForDrag("LeftButton")
hud:SetScript("OnDragStart", hud.StartMoving)
hud:SetScript("OnDragStop", hud.StopMovingOrSizing)
hud:Hide()

-- Dark glassmorphism border / background
hud:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 12, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
hud:SetBackdropColor(0.0, 0.0, 0.0, 0.65)
hud:SetBackdropBorderColor(0.4, 0.4, 0.4, 0.5)

-- Gauge background bar (sliding region)
local bar = hud:CreateTexture(nil, "BORDER")
bar:SetSize(180, 10)
bar:SetPoint("CENTER", 0, -2)
bar:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
-- Gradient coloring: Left is icy-cyan, right is blazing fire-red
bar:SetVertexColor(0.3, 0.6, 0.9, 0.8)

-- Equilibrium visual center marker/border (Equilibrium Zone)
local eqZone = CreateFrame("Frame", nil, hud)
eqZone:SetSize(50, 18)
eqZone:SetPoint("CENTER", 0, -2)
eqZone:SetBackdrop({
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 8,
})
eqZone:SetBackdropBorderColor(0.1, 1.0, 0.2, 0.7) -- Vibrant green indicator

-- Slidable needle indicator
local needle = hud:CreateTexture(nil, "OVERLAY")
needle:SetSize(8, 20)
needle:SetTexture("Interface\\Buttons\\UI-SortArrow") -- vertical pointer arrowhead
needle:SetVertexColor(1.0, 1.0, 1.0, 1.0)
-- Point pointing downward
needle:SetPoint("CENTER", bar, "LEFT", 90, 2)

-- Left Zone Label (Absolute Zero)
local leftLabel = hud:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
leftLabel:SetPoint("LEFT", 5, -2)
leftLabel:SetText("|cff3399ff0|r")

-- Right Zone Label (Supernova)
local rightLabel = hud:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
rightLabel:SetPoint("RIGHT", -5, -2)
rightLabel:SetText("|cfffc3300100|r")

-- Gauge Status Text Label
local hudTitle = hud:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
hudTitle:SetPoint("TOP", 0, -5)
hudTitle:SetText("Equilibrium Gauge")


-- Updates UI representations
local function UpdateUI()
    pointsText:SetText("Available Points: |cff00ff00" .. freePoints .. "|r")
    
    for i = 1, 42 do
        local btn = buttons[i]
        if btn then
            local rank = talentRanks[i] or 0
            local max = TALENTS[i].max
            btn.count:SetText(rank .. "/" .. max)
            
            -- Color icon based on rank (desaturate unlearned ones)
            if rank > 0 then
                btn.icon:SetDesaturated(false)
            else
                btn.icon:SetDesaturated(true)
            end
        end
    end
    
    -- Check if Aethershaper equilibrium gauge should be visible
    local eqLearned = talentRanks[19] or 0
    if eqLearned > 0 then
        hud:Show()
        
        -- Perfect Balance widen zone check (Talent 22)
        local perfBalanceLearned = talentRanks[22] or 0
        local zoneWidth = 50
        if perfBalanceLearned > 0 then
            zoneWidth = 62 -- 25% wider center zone
        end
        eqZone:SetSize(zoneWidth, 18)
        
        -- Update sliding needle position based on equilibrium value (0 - 100)
        local totalWidth = 180 -- width of the bar
        -- x position from left edge of bar (0 to 180)
        local xPos = (equilibriumVal / 100) * totalWidth
        needle:SetPoint("CENTER", bar, "LEFT", xPos, 2)
        
        -- Highlight Equilibrium status if inside zone
        local minZone = 50 - (zoneWidth / 220 * 100)
        local maxZone = 50 + (zoneWidth / 220 * 100)
        if equilibriumVal >= minZone and equilibriumVal <= maxZone then
            hudTitle:SetText("|cff00ff55Equilibrium Active! (+15% Element)|r")
            eqZone:SetBackdropBorderColor(0.0, 1.0, 0.3, 0.9)
        else
            hudTitle:SetText("Equilibrium Gauge (" .. equilibriumVal .. ")")
            eqZone:SetBackdropBorderColor(0.4, 0.4, 0.4, 0.4)
        end
    else
        hud:Hide()
    end
end

-- Register Slash Commands at load time
SLASH_SPELLSLINGER1 = "/spellslinger"
SlashCmdList["SPELLSLINGER"] = function(msg)
    if SpellslingerTalentFrame:IsShown() then
        SpellslingerTalentFrame:Hide()
    else
        SpellslingerTalentFrame:Show()
        -- Ask server for update
        SendAddonMessage(ADDON_PREFIX, "SyncRequest", "WHISPER", UnitName("player"))
    end
end

SLASH_TALENTS1 = "/talents"
SlashCmdList["TALENTS"] = function(msg)
    local _, class = UnitClass("player")
    if class == "HUNTER" then
        if GunslingerTalentFrame and GunslingerTalentFrame:IsShown() then
            GunslingerTalentFrame:Hide()
        elseif GunslingerTalentFrame then
            GunslingerTalentFrame:Show()
            SendAddonMessage("GunslingerTalents", "SyncRequest", "WHISPER", UnitName("player"))
        end
    elseif class == "DEATHKNIGHT" then
        if SpellslingerTalentFrame:IsShown() then
            SpellslingerTalentFrame:Hide()
        else
            SpellslingerTalentFrame:Show()
            SendAddonMessage("SpellslingerTalents", "SyncRequest", "WHISPER", UnitName("player"))
        end
    end
end

-- Network & Addon Message Events
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_LEVEL_UP")

eventFrame:SetScript("OnEvent", function(self, event, prefix, msg, channel, sender)
    if event == "PLAYER_LOGIN" then
        RegisterAddonMessagePrefix(ADDON_PREFIX)
        UpdateUI()
    elseif event == "PLAYER_LEVEL_UP" then
        UpdateUI()
    elseif event == "CHAT_MSG_ADDON" and prefix == ADDON_PREFIX then
        if msg:find("^Sync:") then
            -- Format: Sync:r1:r2:...:r42:totalSpent:freePoints:equilibrium
            local parts = {}
            for val in string.gmatch(msg, "([^:]+)") do
                table.insert(parts, val)
            end
            
            if #parts >= 45 then -- Sync + 42 ranks + spent + freePoints [+ equilibrium]
                for i = 1, 42 do
                    talentRanks[i] = tonumber(parts[i + 1]) or 0
                end
                totalSpent = tonumber(parts[44]) or 0
                freePoints = tonumber(parts[45]) or 0
                if parts[46] then
                    equilibriumVal = tonumber(parts[46]) or 50
                end
                UpdateUI()
            end
        end
    end
end)

DEFAULT_CHAT_FRAME:AddMessage("|cff00ffff[SpellslingerTalents]: Addon loaded successfully. Use /spellslinger or /talents to view subclass tree.|r")
