-- POECraft: Simplified Gear Augmentation Addon (Client-Side)
-- Handles custom orb icon overrides, custom descriptions, and Alt-key details for gear slams.

local ORB_ICONS = {
    [99105] = "Interface\\Icons\\inv_jewelry_talisman_01",   -- Exalted Orb (Talisman Face)
    [99106] = "Interface\\Icons\\inv_misc_gem_diamond_02",    -- Orb of Scouring (White Diamond)
    [99108] = "Interface\\Icons\\inv_misc_gem_bloodstone_02", -- Vaal Orb (Red Gem)
    [99109] = "Interface\\Icons\\inv_misc_orb_01",            -- Map Chaos Orb (Purple Glowing Orb)
    [99200] = "Interface\\Icons\\inv_misc_map_01",            -- Exile's Dungeon Map (Original Entry)
    [99205] = "Interface\\Icons\\inv_misc_map_01",            -- Exile's Dungeon Map (Active Entry)
}

-- Hook GetItemIcon
local original_GetItemIcon = GetItemIcon
function GetItemIcon(item)
    if item then
        local itemID
        if type(item) == "number" then
            itemID = item
        else
            itemID = tonumber(tostring(item):match("item:(%d+)"))
        end
        if itemID and ORB_ICONS[itemID] then
            return ORB_ICONS[itemID]
        end
    end
    return original_GetItemIcon(item)
end

-- Hook GetItemInfo
local original_GetItemInfo = GetItemInfo
function GetItemInfo(item)
    if not item then return nil end
    local itemID
    if type(item) == "number" then
        itemID = item
    else
        itemID = tonumber(tostring(item):match("item:(%d+)"))
    end
    if itemID and ORB_ICONS[itemID] then
        local name, link, quality, iLevel, reqLevel, class, subclass, maxStack, equipSlot, texture, vendorPrice = original_GetItemInfo(item)
        if name then
            return name, link, quality, iLevel, reqLevel, class, subclass, maxStack, equipSlot, ORB_ICONS[itemID], vendorPrice
        end
    end
    return original_GetItemInfo(item)
end

-- Hook GetContainerItemInfo
local original_GetContainerItemInfo = GetContainerItemInfo
function GetContainerItemInfo(bag, slot)
    local texture, itemCount, locked, quality, readable, lootable, itemLink, isFiltered = original_GetContainerItemInfo(bag, slot)
    if bag and slot then
        local itemID = GetContainerItemID(bag, slot)
        if itemID and ORB_ICONS[itemID] then
            return ORB_ICONS[itemID], itemCount, locked, quality, readable, lootable, itemLink, isFiltered
        end
    end
    return texture, itemCount, locked, quality, readable, lootable, itemLink, isFiltered
end

-- Hook GetLootSlotInfo
local original_GetLootSlotInfo = GetLootSlotInfo
function GetLootSlotInfo(slot)
    local texture, name, count, quality, locked = original_GetLootSlotInfo(slot)
    local link = GetLootSlotLink(slot)
    if link then
        local itemID = tonumber(link:match("item:(%d+)"))
        if itemID and ORB_ICONS[itemID] then
            return ORB_ICONS[itemID], name, count, quality, locked
        end
    end
    return texture, name, count, quality, locked
end

local ORB_TOOLTIPS = {
    [99105] = {
        use = "Use: Adds a random custom stat slam to a weapon or armor (Max 2).",
        desc = "Slams a random bonus stat onto any weapon or armor item."
    },
    [99106] = {
        use = "Use: Wipes all custom slams from an item.",
        desc = "Removes all custom Exalted stat slams, returning the item to its native state."
    },
    [99108] = {
        use = "Use: Corrupts an item, adding a powerful implicit stat. Blocks further modifications. (WARNING: 25% chance to brick and wipe slams)",
        desc = "Corrupts an item, modifying its implicit properties unpredictably."
    },
    [99109] = {
        use = "Use: Rerolls the affixes of an Exile's Dungeon Map in your bags.",
        desc = "Rerolls the random modifiers on a custom dungeon map."
    },
    [99200] = {
        use = "Use: Inspects the map's level, quantity, rarity, and active affixes."
    },
    [99205] = {
        use = "Use: Inspects the map's level, quantity, rarity, and active affixes."
    }
}

local SLAM_ENCHANTS = {
    -- Tier 1: level 1-19
    [79] = true, [80] = true, [81] = true, [82] = true, [83] = true, [84] = true,
    [68] = true, [69] = true, [70] = true, [74] = true, [75] = true, [76] = true,
    [71] = true, [72] = true, [73] = true, [85] = true, [86] = true,
    -- Tier 2: level 20-39
    [94] = true, [95] = true, [98] = true, [99] = true, [208] = true, [209] = true,
    [106] = true, [107] = true, [90] = true, [91] = true, [117] = true, [118] = true,
    [102] = true, [103] = true, [87] = true, [89] = true,
    -- Tier 3: level 40-59
    [359] = true, [360] = true, [1118] = true, [1144] = true, [212] = true, [429] = true,
    [358] = true, [362] = true, [684] = true, [883] = true,
    [361] = true, [1068] = true, [121] = true, [257] = true,
    -- Tier 4: level 60+
    [1123] = true, [1133] = true, [1149] = true, [1159] = true,
    [1047] = true, [1057] = true, [1097] = true, [1107] = true,
    [1073] = true, [1083] = true
}

-- Vaal implicit pools
local VAAL_IMPLICITS = {
    -- Tier 1
    [69] = {tier=1, stat="Strength", val=2},
    [75] = {tier=1, stat="Agility", val=2},
    [80] = {tier=1, stat="Intellect", val=2},
    [83] = {tier=1, stat="Spirit", val=2},
    [72] = {tier=1, stat="Stamina", val=2},
    [1336] = {tier=1, stat="Fire Resistance", val=2},
    -- Tier 2
    [70] = {tier=2, stat="Strength", val=3},
    [76] = {tier=2, stat="Agility", val=3},
    [81] = {tier=2, stat="Intellect", val=3},
    [84] = {tier=2, stat="Spirit", val=3},
    [73] = {tier=2, stat="Stamina", val=3},
    [1337] = {tier=2, stat="Fire Resistance", val=3},
    -- Tier 3
    [108] = {tier=3, stat="Strength", val=6},
    [92] = {tier=3, stat="Agility", val=6},
    [96] = {tier=3, stat="Intellect", val=6},
    [100] = {tier=3, stat="Spirit", val=6},
    [104] = {tier=3, stat="Stamina", val=6},
    [1340] = {tier=3, stat="Fire Resistance", val=6},
    -- Tier 4
    [362] = {tier=4, stat="Strength", val=10},
    [358] = {tier=4, stat="Agility", val=10},
    [359] = {tier=4, stat="Intellect", val=10},
    [360] = {tier=4, stat="Spirit", val=10},
    [361] = {tier=4, stat="Stamina", val=10},
    [1344] = {tier=4, stat="Fire Resistance", val=10},
    [2934] = {tier=4, stat="Critical Strike", val=10}
}

-- Hidden scanner tooltip to resolve enchantment descriptions locally
local scanner = CreateFrame("GameTooltip", "POECraftScanner", nil, "GameTooltipTemplate")
scanner:SetOwner(WorldFrame, "ANCHOR_NONE")

local enchantCache = {}
local function GetEnchantDescription(enchantId)
    if not enchantId or enchantId == 0 then return nil end
    if enchantCache[enchantId] then
        return enchantCache[enchantId]
    end
    scanner:ClearLines()
    scanner:SetHyperlink("item:25:" .. enchantId .. ":0:0:0:0:0:0")
    local numLines = scanner:NumLines()
    for i = 2, numLines do
        local line = _G["POECraftScannerTextLeft" .. i]
        if line then
            local text = line:GetText()
            if text and text ~= "" then
                local r, g, b = line:GetTextColor()
                if r < 0.2 and g > 0.8 and b < 0.2 then
                    enchantCache[enchantId] = text
                    return text
                end
            end
        end
    end
    return nil
end

local vaalDescs = {}
local vaalResolved = false
local function ResolveVaalDescriptions()
    if vaalResolved then return end
    local allResolved = true
    for id, info in pairs(VAAL_IMPLICITS) do
        if not vaalDescs[id] then
            local desc = GetEnchantDescription(id)
            if desc then
                vaalDescs[desc] = id
                vaalDescs[id] = desc
            else
                allResolved = false
            end
        end
    end
    if allResolved then
        vaalResolved = true
    end
end

-- Helper to update custom Orb tooltips
local function UpdateOrbTooltip(self, itemId)
    local config = ORB_TOOLTIPS[itemId]
    if not config then return end
    
    local numLines = self:NumLines()
    for i = 1, numLines do
        local line = _G[self:GetName() .. "TextLeft" .. i]
        if line then
            local text = line:GetText()
            if text then
                if text:find("^Use:") then
                    line:SetText(config.use)
                    line:SetTextColor(0.0, 1.0, 0.0) -- Green
                elseif config.desc and (text:find(config.desc, 1, true) or text:find('"' .. config.desc .. '"', 1, true)) then
                    line:SetText("Used in Exile Augmentation")
                    line:SetTextColor(0.5, 0.5, 0.5) -- Grey
                end
            end
        end
    end
    self:Show()
end

-- Get slam details (Tiers/Ranges) based on text values
local function GetSlamDetail(text)
    if not text then return nil end
    
    -- Match +value statName (e.g. +5 Intellect, +30 Stamina)
    local valStr, statName = text:match("^+([0-9]+)%s+(.+)$")
    if not valStr or not statName then
        -- Match armor values
        valStr, statName = text:match("^([0-9]+)%s+(Armor)$")
        if not valStr then
            valStr, statName = text:match("^+([0-9]+)%s+(Armor)$")
        end
    end
    
    if not valStr or not statName then return nil end
    local val = tonumber(valStr)
    local nameLower = statName:lower()
    
    local isSpellOrAp = nameLower:find("spell") or nameLower:find("attack") or nameLower:find("power") or nameLower:find("damage") or nameLower:find("healing")
    local isArmor = nameLower:find("armor")
    
    local tier, rangeStr
    if isSpellOrAp then
        if val <= 5 then
            tier, rangeStr = 2, "4-5"
        elseif val <= 8 then
            tier, rangeStr = 3, "8"
        else
            tier, rangeStr = 4, "20-30" -- Fallback/Custom
        end
    elseif isArmor then
        if val <= 20 then
            tier, rangeStr = 1, "10-20"
        elseif val <= 40 then
            tier, rangeStr = 2, "30-40"
        else
            tier, rangeStr = 3, "50-80"
        end
    else
        -- Intellect, Spirit, Strength, Agility, Stamina
        if val <= 3 then
            tier, rangeStr = 1, "1-3"
        elseif val <= 5 then
            tier, rangeStr = 2, "4-5"
        elseif val <= 15 then
            tier, rangeStr = 3, "8-15"
        else
            tier, rangeStr = 4, "20-30"
        end
    end
    return string.format("(Slam T%d: +%s)", tier, rangeStr)
end

local function GetVaalDetail(vaalId)
    local info = VAAL_IMPLICITS[vaalId]
    if not info then return nil end
    return string.format("(Implicit T%d: +%d)", info.tier, info.val)
end

-- Hook Tooltips to append Alt-key details and format Orbs
local function ColorTooltip(self)
    local _, link = self:GetItem()
    if link then
        local _, _, itemIdStr = string.find(link, "item:(%d+)")
        local itemId = tonumber(itemIdStr)
        if itemId and ORB_TOOLTIPS[itemId] then
            UpdateOrbTooltip(self, itemId)
            return
        end
        
        local _, _, itemString = string.find(link, "item:([^|]+)")
        if not itemString then return end
        local parts = { strsplit(":", itemString) }
        
        local slot0Id = tonumber(parts[2])
        local slot5Id = tonumber(parts[6])
        
        ResolveVaalDescriptions()
        
        -- Scan green lines on the tooltip to identify active slams or Vaal implicit
        local numLines = self:NumLines()
        local slamCount = 0
        local isCorrupted = false
        
        local slot0Desc = slot0Id and GetEnchantDescription(slot0Id)
        local slot5Desc = slot5Id and GetEnchantDescription(slot5Id)
        
        local slot0Matched = false
        local slot5Matched = false
        
        for i = 2, numLines do
            local line = _G[self:GetName() .. "TextLeft" .. i]
            if line then
                local text = line:GetText()
                if text and text ~= "" then
                    local r, g, b = line:GetTextColor()
                    local isGreen = (r < 0.2 and g > 0.8 and b < 0.2)
                    if isGreen then
                        -- Check Slot 0 Custom Slam
                        if slot0Desc and text == slot0Desc and SLAM_ENCHANTS[slot0Id] and not slot0Matched then
                            slot0Matched = true
                            slamCount = slamCount + 1
                            if IsAltKeyDown() and not text:find("%(Slam T") then
                                local detail = GetSlamDetail(text)
                                if detail then
                                    line:SetText(text .. "  |cff888888" .. detail .. "|r")
                                end
                            end
                        -- Check Slot 5 Custom Slam
                        elseif slot5Desc and text == slot5Desc and SLAM_ENCHANTS[slot5Id] and not slot5Matched then
                            slot5Matched = true
                            slamCount = slamCount + 1
                            if IsAltKeyDown() and not text:find("%(Slam T") then
                                local detail = GetSlamDetail(text)
                                if detail then
                                    line:SetText(text .. "  |cff888888" .. detail .. "|r")
                                end
                            end
                        -- Check Vaal Implicit
                        else
                            local vaalId = vaalDescs[text]
                            if vaalId then
                                isCorrupted = true
                                if IsAltKeyDown() then
                                    local detail = GetVaalDetail(vaalId)
                                    if detail then
                                        line:SetText("|cffba55d3[Corrupted] " .. text .. "  |cff888888" .. detail .. "|r")
                                    else
                                        line:SetText("|cffba55d3[Corrupted] " .. text .. "|r")
                                    end
                                else
                                    line:SetText("|cffba55d3[Corrupted] " .. text .. "|r")
                                end
                            else
                                -- Match legacy custom slams in Slot 6 or Slot 7
                                local detail = GetSlamDetail(text)
                                if detail then
                                    slamCount = slamCount + 1
                                    if IsAltKeyDown() and not text:find("%(Slam T") then
                                        line:SetText(text .. "  |cff888888" .. detail .. "|r")
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
        
        -- Append Alt-key double line summary showing total custom slams
        if (slamCount > 0 or isCorrupted) and IsAltKeyDown() then
            self:AddDoubleLine("Custom Slams:", "|cff1eff00" .. slamCount .. "/2|r", 0.5, 0.5, 0.5)
        end
        
        if isCorrupted then
            self:AddLine("Corrupted", 1.0, 0.1, 0.1)
        end
    end
end

local function SafeHookTooltip(tooltip)
    if tooltip and tooltip.HookScript then
        tooltip:HookScript("OnTooltipSetItem", ColorTooltip)
    end
end

SafeHookTooltip(GameTooltip)
SafeHookTooltip(ItemRefTooltip)
SafeHookTooltip(ShoppingTooltip1)
SafeHookTooltip(ShoppingTooltip2)

-- Frame to listen to Alt modifier state changes and refresh the active tooltip instantly
local modifierFrame = CreateFrame("Frame")
modifierFrame:RegisterEvent("MODIFIER_STATE_CHANGED")
modifierFrame:SetScript("OnEvent", function(self, event, key, state)
    if key == "LALT" or key == "RALT" or key == "ALT" then
        if GameTooltip:IsShown() and GameTooltip:GetItem() then
            local owner = GameTooltip:GetOwner()
            if owner then
                local onEnter = owner:GetScript("OnEnter")
                if onEnter then
                    onEnter(owner)
                end
            end
        end
        if ItemRefTooltip:IsShown() then
            local _, link = ItemRefTooltip:GetItem()
            if link then
                ItemRefTooltip:SetHyperlink(link)
            end
        end
    end
end)
