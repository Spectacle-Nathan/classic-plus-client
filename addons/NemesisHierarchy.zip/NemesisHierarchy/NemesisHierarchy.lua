-- Custom WoW Client Addon: Nemesis Hierarchy UI
-- Author: Antigravity

local ADDON_PREFIX = "NemesisSystem"

local RACES = {
    [1] = "Human", [2] = "Orc", [3] = "Dwarf", [4] = "Night Elf",
    [5] = "Undead", [6] = "Tauren", [7] = "Gnome", [8] = "Troll",
    [10] = "Blood Elf", [11] = "Draenei"
}

local CLASSES = {
    [1] = "Warrior", [2] = "Paladin", [3] = "Hunter", [4] = "Rogue",
    [5] = "Priest", [6] = "Death Knight", [7] = "Shaman", [8] = "Mage",
    [9] = "Warlock", [11] = "Druid"
}

local CLASS_TEX_COORDS = {
    ["Warrior"]      = {0, 0.25, 0, 0.25},
    ["Mage"]         = {0.25, 0.5, 0, 0.25},
    ["Rogue"]        = {0.5, 0.75, 0, 0.25},
    ["Druid"]        = {0.75, 1, 0, 0.25},
    ["Hunter"]       = {0, 0.25, 0.25, 0.5},
    ["Shaman"]       = {0.25, 0.5, 0.25, 0.5},
    ["Priest"]       = {0.5, 0.75, 0.25, 0.5},
    ["Warlock"]      = {0.75, 1, 0.25, 0.5},
    ["Paladin"]      = {0, 0.25, 0.5, 0.75},
    ["Death Knight"] = {0.25, 0.5, 0.5, 0.75}
}

local RANK_TITLES = {
    [0] = "Neutral",
    [1] = "Scourge",
    [2] = "Marauder",
    [3] = "Slayer",
    [4] = "Dreadlord",
    [5] = "Grand Inquisitor"
}

local RANK_COLORS = {
    [0] = "|cff808080", -- Grey
    [1] = "|cff00ff00", -- Green
    [2] = "|cff00ffff", -- Cyan
    [3] = "|cff9370db", -- Purple
    [4] = "|cffffa500", -- Orange
    [5] = "|cffff0000"  -- Red
}

local TRAIT_INFO = {
    ["BLOODTHIRSTY"] = { name = "Bloodthirsty", desc = "Lifesteal: Heals for 20% of all damage dealt to you.", isWeakness = false },
    ["ENRAGED_LOW"] = { name = "Enraged", desc = "Enrages when under 35% health, increasing attack speed and damage by 50%.", isWeakness = false },
    ["IRON_WILL"] = { name = "Iron Will", desc = "Takes 30% less damage from physical attacks.", isWeakness = false },
    ["SPELL_SHIELD"] = { name = "Spell Shield", desc = "Has a 30% chance to reflect offensive spells back to you.", isWeakness = false },
    ["CC_RESIST"] = { name = "Iron Mind", desc = "Automatically breaks stuns, fears, and root effects every 10 seconds.", isWeakness = false },
    ["SHIELD_LOW"] = { name = "Arcane Barrier", desc = "Gains a shield absorbing 25% max health when dropping below 20% HP.", isWeakness = false },
    ["VULN_FIRE"] = { name = "Vulnerable to Fire", desc = "Takes 50% extra damage from your Fire spells.", isWeakness = true },
    ["VULN_FROST"] = { name = "Vulnerable to Frost", desc = "Takes 50% extra damage from your Frost spells.", isWeakness = true }
}

-- Utility function to split string
local function split(str, sep)
    local result = {}
    local from = 1
    local delim_from, delim_to = string.find(str, sep, from)
    while delim_from do
        table.insert(result, string.sub(str, from, delim_from - 1))
        from = delim_to + 1
        delim_from, delim_to = string.find(str, sep, from)
    end
    table.insert(result, string.sub(str, from))
    return result
end

-- Create Main Hierarchy UI
local frame = CreateFrame("Frame", "NemesisHierarchyFrame", UIParent)
frame:SetSize(850, 560)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:SetScript("OnHide", function(self)
    if WantedBoardFrame and self.openedFromBoard then
        self.openedFromBoard = nil
        WantedBoardFrame:Show()
    end
end)
frame:Hide()

frame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 16, edgeSize = 20,
    insets = { left = 5, right = 5, top = 5, bottom = 5 }
})
frame:SetBackdropColor(0.06, 0.05, 0.05, 0.96)
frame:SetBackdropBorderColor(0.4, 0.2, 0.2, 0.9) -- Reddish border

-- Title
local titleText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
titleText:SetPoint("TOP", 0, -18)
titleText:SetText("|cffff2222NEMESIS HIERARCHY - ACTIVE RIVALS|r")

-- Close Button
local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -6, -6)

-- Scroll Area
local scrollFrame = CreateFrame("ScrollFrame", "NemesisHierarchyScroll", frame, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", 15, -50)
scrollFrame:SetPoint("BOTTOMRIGHT", -35, 20)

local scrollChild = CreateFrame("Frame", nil, scrollFrame)
scrollChild:SetSize(780, 480)
scrollFrame:SetScrollChild(scrollChild)

-- Rivals cards pool
local rivalCards = {}

-- Create a single rival profile card
local function CreateRivalCard(i)
    local card = CreateFrame("Frame", nil, scrollChild)
    card:SetSize(770, 96)
    card:SetPoint("TOPLEFT", 5, -(i-1)*102)
    card:SetBackdrop({
        bgFile = "Interface\\AchievementFrame\\UI-Achievement-Parchment-Horizontal",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 256, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    })
    card:SetBackdropColor(0.95, 0.92, 0.88, 1.0)
    card:SetBackdropBorderColor(0.5, 0.2, 0.2, 0.6)
    
    -- Class Icon
    local classIcon = card:CreateTexture(nil, "OVERLAY")
    classIcon:SetSize(44, 44)
    classIcon:SetPoint("LEFT", 15, 0)
    classIcon:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
    card.classIcon = classIcon
    
    -- Identity text (Name & Title)
    local idText = card:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    idText:SetPoint("TOPLEFT", 75, -12)
    idText:SetText("")
    card.idText = idText
    
    -- Stats text (Rank, Level, Wins, Losses)
    local statsText = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    statsText:SetPoint("TOPLEFT", 75, -34)
    statsText:SetJustifyH("LEFT")
    statsText:SetSpacing(2)
    card.statsText = statsText
    
    -- Location & Status text
    local locText = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    locText:SetPoint("TOPLEFT", 75, -68)
    locText:SetJustifyH("LEFT")
    card.locText = locText
    
    -- Traits Label
    local traitsLabel = card:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    traitsLabel:SetPoint("TOPLEFT", 320, -12)
    traitsLabel:SetText("|cff555555Combat Traits:|r")
    card.traitsLabel = traitsLabel
    
    -- Traits containers
    card.traitBadges = {}
    for j = 1, 4 do
        local badge = CreateFrame("Frame", nil, card)
        badge:SetSize(100, 20)
        badge:SetPoint("TOPLEFT", 320, -18 - (j*16))
        badge:SetBackdrop({
            bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 16, edgeSize = 8,
            insets = { left = 1, right = 1, top = 1, bottom = 1 }
        })
        
        local text = badge:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        text:SetPoint("CENTER", 0, 0)
        badge.text = text
        
        badge:Hide()
        card.traitBadges[j] = badge
    end
    
    -- Incite Hunt Button
    local huntBtn = CreateFrame("Button", nil, card, "UIPanelButtonTemplate")
    huntBtn:SetSize(120, 24)
    huntBtn:SetPoint("RIGHT", -15, 0)
    huntBtn:SetText("Incite Hunt")
    card.huntBtn = huntBtn
    
    card:Hide()
    return card
end

-- Update Hierarchy Panel
local function UpdateHierarchyUI(msgData)
    -- Hide all existing cards
    for _, card in ipairs(rivalCards) do
        card:Hide()
    end
    
    if not msgData or msgData == "" or msgData == "None" then
        -- Handle no rivals case
        return
    end
    
    local rows = split(msgData, ";")
    local yOffset = 0
    for i, rowData in ipairs(rows) do
        -- Format: botGuidStr#botName#botLvl#botRace#botClass#victories#defeats#rank#level#title#traits#zoneName#status
        local parts = split(rowData, "#")
        if #parts >= 13 then
            local botGuidStr = parts[1]
            local name = parts[2]
            local botLvl = tonumber(parts[3]) or 1
            local raceId = tonumber(parts[4]) or 1
            local classId = tonumber(parts[5]) or 1
            local victories = tonumber(parts[6]) or 0 -- bot victories over player
            local defeats = tonumber(parts[7]) or 0 -- bot defeats by player
            local rank = tonumber(parts[8]) or 1
            local rivalLevel = tonumber(parts[9]) or 1
            local title = parts[10]
            local traitsStr = parts[11]
            local zoneName = parts[12]
            local status = parts[13]
            
            local raceName = RACES[raceId] or "Human"
            local className = CLASSES[classId] or "Warrior"
            local rankTitle = RANK_TITLES[rank] or "Neutral"
            local colorPrefix = RANK_COLORS[rank] or "|cffffffff"
            
            local card = rivalCards[i]
            if not card then
                card = CreateRivalCard(i)
                rivalCards[i] = card
            end
            
            -- Class Icon
            local coords = CLASS_TEX_COORDS[className]
            if coords then
                card.classIcon:SetTexCoord(unpack(coords))
            end
            
            -- Title & Identity
            local displayName = name
            if title and title ~= "" then
                displayName = name .. " " .. title
            end
            card.idText:SetText(colorPrefix .. displayName .. "|r")
            
            -- Stats & Rank
            local statStr = string.format("Rival Level: |cff00ff00%d|r  |  Rank: %s%s|r\nRecord vs You: |cffff0000%d Wins|r  /  |cff00ff00%d Losses|r",
                rivalLevel, colorPrefix, rankTitle, victories, defeats)
            card.statsText:SetText(statStr)
            
            -- Location & Status
            local statusColor = (status == "Online") and "|cff00ff00Online|r" or "|cff808080Offline|r"
            card.locText:SetText(string.format("Last Seen: |cff8b4513%s|r (%s)", zoneName, statusColor))
            
            -- Render Traits
            -- Hide all badges first
            for _, badge in ipairs(card.traitBadges) do
                badge:Hide()
            end
            
            local activeTraits = {}
            if traitsStr and traitsStr ~= "" then
                activeTraits = split(traitsStr, ",")
            end
            
            if #activeTraits > 0 then
                card.traitsLabel:SetText("|cff4b0082Combat Traits:|r")
                for j, traitId in ipairs(activeTraits) do
                    local info = TRAIT_INFO[traitId]
                    local badge = card.traitBadges[j]
                    if info and badge then
                        badge.text:SetText(info.name)
                        
                        -- Color badge border/background based on strength/weakness
                        if info.isWeakness then
                            badge:SetBackdropColor(0.1, 0.25, 0.4, 0.8) -- Blue/Cyan
                            badge:SetBackdropBorderColor(0.2, 0.5, 0.8, 0.9)
                            badge.text:SetTextColor(0.4, 0.8, 1.0)
                        else
                            badge:SetBackdropColor(0.4, 0.1, 0.1, 0.8) -- Red/Orange
                            badge:SetBackdropBorderColor(0.8, 0.2, 0.2, 0.9)
                            badge.text:SetTextColor(1.0, 0.3, 0.3)
                        end
                        
                        -- Set tooltip scripts
                        badge:SetScript("OnEnter", function(self)
                            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                            GameTooltip:ClearLines()
                            GameTooltip:AddLine(info.name, 1, 1, 1)
                            GameTooltip:AddLine(info.desc, 0.8, 0.8, 0.8, true)
                            GameTooltip:Show()
                        end)
                        badge:SetScript("OnLeave", function()
                            GameTooltip:Hide()
                        end)
                        
                        badge:Show()
                    end
                end
            else
                card.traitsLabel:SetText("|cff808080No active combat traits.|r")
            end
            
            -- Incite Hunt Button Action
            if status == "Online" then
                card.huntBtn:Enable()
                card.huntBtn:SetScript("OnClick", function()
                    SendAddonMessage("NemesisSystem", "RequestHuntSpecific:" .. botGuidStr, "WHISPER", UnitName("player"))
                    DEFAULT_CHAT_FRAME:AddMessage("|cffff0000[Nemesis]: Preparing targeted hunt on rival " .. name .. "...|r")
                    frame:Hide()
                end)
            else
                card.huntBtn:Disable()
                card.huntBtn:SetScript("OnClick", nil)
            end
            
            card:Show()
            yOffset = yOffset + 102
        end
    end
    scrollChild:SetSize(780, math.max(480, yOffset))
end

-- Network Message Listener
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("ADDON_LOADED")

eventFrame:SetScript("OnEvent", function(self, event, prefix, msg, channel, sender)
    if event == "PLAYER_LOGIN" then
        RegisterAddonMessagePrefix(ADDON_PREFIX)
        
    elseif event == "CHAT_MSG_ADDON" and prefix == ADDON_PREFIX then
        if msg:find("^HierarchySync:") then
            local data = msg:sub(15)
            UpdateHierarchyUI(data)
            frame:Show()
        end
        
    elseif event == "ADDON_LOADED" then
        -- Check if both addons are loaded and hook button
        if WantedBoardFrame and not frame.linkedButton then
            local btn = CreateFrame("Button", nil, WantedBoardFrame, "UIPanelButtonTemplate")
            btn:SetSize(160, 24)
            btn:SetPoint("BOTTOMLEFT", WantedBoardFrame, "BOTTOMLEFT", 15, 12)
            btn:SetText("Rival Hierarchy")
            btn:SetScript("OnClick", function()
                if frame:IsShown() then
                    frame:Hide()
                else
                    frame.openedFromBoard = true
                    WantedBoardFrame:Hide()
                    SendAddonMessage(ADDON_PREFIX, "RequestHierarchy", "WHISPER", UnitName("player"))
                end
            end)
            frame.linkedButton = btn
        end
    end
end)

-- Slash Command support
SLASH_NEMESISHIERARCHY1 = "/hierarchy"
SLASH_NEMESISHIERARCHY2 = "/nemesisui"
SlashCmdList["NEMESISHIERARCHY"] = function(msg)
    if frame:IsShown() then
        frame:Hide()
    else
        if WantedBoardFrame and WantedBoardFrame:IsShown() then
            frame.openedFromBoard = true
            WantedBoardFrame:Hide()
        end
        SendAddonMessage(ADDON_PREFIX, "RequestHierarchy", "WHISPER", UnitName("player"))
    end
end

DEFAULT_CHAT_FRAME:AddMessage("|cffff2222[NemesisHierarchy]: Addon loaded. Type /hierarchy or open the Wanted Board and click Rival Hierarchy to view.|r")
