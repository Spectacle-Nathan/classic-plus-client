-- Client-side Addon: Zone Invasions Tracker
-- Tracks active invasions, lists level requirements, and provides a GM dashboard and World Map alerts.
-- Author: Antigravity

local ADDON_PREFIX = "InvasionsSystem"
local activeInvasions = {} -- zoneId -> { theme, phase, remaining, phase2 }
local isGM = false

local INVASION_ZONES = {
    [40] = { name = "Westfall", levelMin = 10, levelMax = 20 },
    [44] = { name = "Redridge Mountains", levelMin = 15, levelMax = 25 },
    [10] = { name = "Duskwood", levelMin = 18, levelMax = 30 },
    [33] = { name = "Stranglethorn Vale", levelMin = 30, levelMax = 45 },
    [440] = { name = "Tanaris", levelMin = 40, levelMax = 50 },
    [1377] = { name = "Silithus", levelMin = 55, levelMax = 60 }
}

local ZONE_ORDER = { 40, 44, 10, 33, 440, 1377 }

-- Create the main UI frame
local frame = CreateFrame("Frame", "InvasionsFrame", UIParent)
frame:SetSize(620, 380)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:Hide()

frame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
frame:SetBackdropColor(0.04, 0.05, 0.08, 0.90) -- Premium dark glassmorphic bg
frame:SetBackdropBorderColor(0.12, 0.45, 0.8, 0.85) -- Cyan/Blue glow border

-- Header Title
local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOP", 0, -15)
title:SetText("Zone Invasions Tracker")
title:SetTextColor(1.0, 0.82, 0.0) -- Gold

-- Close Button
local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -4, -4)

-- Table Headers
local hZone = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
hZone:SetPoint("TOPLEFT", 25, -45)
hZone:SetText("Zone Name")
hZone:SetTextColor(0.6, 0.6, 0.7)

local hLvl = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
hLvl:SetPoint("TOPLEFT", 160, -45)
hLvl:SetText("Levels")
hLvl:SetTextColor(0.6, 0.6, 0.7)

local hStatus = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
hStatus:SetPoint("TOPLEFT", 230, -45)
hStatus:SetText("Status")
hStatus:SetTextColor(0.6, 0.6, 0.7)

local hDetails = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
hDetails:SetPoint("TOPLEFT", 380, -45)
hDetails:SetText("Details")
hDetails:SetTextColor(0.6, 0.6, 0.7)

-- Row frames
local rows = {}
for i, zoneId in ipairs(ZONE_ORDER) do
    local zConf = INVASION_ZONES[zoneId]
    local r = CreateFrame("Frame", nil, frame)
    r:SetSize(580, 42)
    r:SetPoint("TOPLEFT", 20, -55 - (i * 42))
    
    r:SetBackdrop({
        bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 8,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    r:SetBackdropColor(0.08, 0.09, 0.13, 0.4)
    r:SetBackdropBorderColor(0.2, 0.25, 0.35, 0.3)
    
    -- Zone name
    local txtName = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    txtName:SetPoint("LEFT", 10, 0)
    txtName:SetText(zConf.name)
    
    -- Level requirements
    local txtLvl = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    txtLvl:SetPoint("LEFT", 140, 0)
    txtLvl:SetText(string.format("%d - %d", zConf.levelMin, zConf.levelMax))
    txtLvl:SetTextColor(0.7, 0.7, 0.8)
    
    -- Status text
    local txtStatus = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    txtStatus:SetPoint("LEFT", 210, 0)
    txtStatus:SetText("Safe")
    txtStatus:SetTextColor(0.1, 0.9, 0.1) -- Safe (green)
    
    -- Details text
    local txtDetails = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    txtDetails:SetPoint("LEFT", 360, 0)
    txtDetails:SetText("-")
    txtDetails:SetTextColor(0.7, 0.7, 0.7)
    
    -- GM Start Button
    local startBtn = CreateFrame("Button", nil, r, "UIPanelButtonTemplate")
    startBtn:SetSize(50, 24)
    startBtn:SetPoint("RIGHT", -60, 0)
    startBtn:SetText("Start")
    startBtn:SetScript("OnClick", function()
        SendAddonMessage(ADDON_PREFIX, "RequestStart:" .. zoneId, "WHISPER", UnitName("player"))
    end)
    startBtn:Hide()
    
    -- GM Stop Button
    local stopBtn = CreateFrame("Button", nil, r, "UIPanelButtonTemplate")
    stopBtn:SetSize(50, 24)
    stopBtn:SetPoint("RIGHT", -5, 0)
    stopBtn:SetText("Stop")
    stopBtn:SetScript("OnClick", function()
        SendAddonMessage(ADDON_PREFIX, "RequestStop:" .. zoneId, "WHISPER", UnitName("player"))
    end)
    stopBtn:Hide()
    
    rows[zoneId] = {
        frame = r,
        statusText = txtStatus,
        detailsText = txtDetails,
        startBtn = startBtn,
        stopBtn = stopBtn
    }
end

-- Refresh UI function
local function RefreshUI()
    for zoneId, rData in pairs(rows) do
        local status = activeInvasions[zoneId]
        if status and status.theme ~= "Safe" then
            rData.statusText:SetText("|cffff0000" .. status.theme .. "|r")
            
            local detailStr = ""
            if status.phase == 1 then
                detailStr = string.format("Phase 1: Portals (%d/3 remaining)", status.remaining)
            elseif status.phase == 2 then
                detailStr = "|cffff9900Phase 2: Boss Active!|r"
            end
            rData.detailsText:SetText(detailStr)
            rData.frame:SetBackdropColor(0.2, 0.05, 0.05, 0.5) -- Dark red for danger
            rData.frame:SetBackdropBorderColor(0.8, 0.2, 0.2, 0.6)
        else
            rData.statusText:SetText("Safe")
            rData.statusText:SetTextColor(0.1, 0.9, 0.1)
            rData.detailsText:SetText("-")
            rData.detailsText:SetTextColor(0.7, 0.7, 0.7)
            rData.frame:SetBackdropColor(0.08, 0.09, 0.13, 0.4)
            rData.frame:SetBackdropBorderColor(0.2, 0.25, 0.35, 0.3)
        end
        
        -- Show GM controls if user is GM
        if isGM then
            rData.startBtn:Show()
            rData.stopBtn:Show()
        else
            rData.startBtn:Hide()
            rData.stopBtn:Hide()
        end
    end
end

-- Sync request
local function SendSyncRequest()
    SendAddonMessage(ADDON_PREFIX, "RequestSync", "WHISPER", UnitName("player"))
end

-- Automatically sync every 10 seconds if frame is visible
local timerFrame = CreateFrame("Frame")
timerFrame:Hide()
local lastSync = 0
timerFrame:SetScript("OnUpdate", function(self, elapsed)
    lastSync = lastSync + elapsed
    if lastSync >= 10 then
        lastSync = 0
        SendSyncRequest()
    end
end)

frame:SetScript("OnShow", function()
    PlaySound("igCharacterInfoOpen")
    SendSyncRequest()
    timerFrame:Show()
end)

frame:SetScript("OnHide", function()
    PlaySound("igCharacterInfoClose")
    timerFrame:Hide()
end)

-- Draggable Minimap Button
local minimapBtn = CreateFrame("Button", "InvasionsMinimapBtn", Minimap)
minimapBtn:SetSize(32, 32)
minimapBtn:SetFrameStrata("MEDIUM")
minimapBtn:SetFrameLevel(Minimap:GetFrameLevel() + 5)
minimapBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

local btnBorder = minimapBtn:CreateTexture(nil, "BACKGROUND")
btnBorder:SetSize(52, 52)
btnBorder:SetPoint("TOPLEFT", -10, 10)
btnBorder:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

local btnIcon = minimapBtn:CreateTexture(nil, "BORDER")
btnIcon:SetSize(20, 20)
btnIcon:SetPoint("CENTER", 0, 0)
btnIcon:SetTexture("Interface\\Icons\\Spell_Arcane_PortalUndercity") -- Custom portal texture

minimapBtn:RegisterForDrag("LeftButton")
minimapBtn:RegisterForClicks("AnyUp")
minimapBtn:Show()

-- Position logic
local function UpdateMinimapButtonPos()
    local angle = InvasionsMinimapBtnPosition or 45
    local x = math.cos(math.rad(angle)) * 80
    local y = math.sin(math.rad(angle)) * 80
    minimapBtn:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

minimapBtn:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function(self)
        local mx, my = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        mx, my = mx / scale, my / scale
        local cx, cy = Minimap:GetCenter()
        local angle = math.atan2(my - cy, mx - cx)
        InvasionsMinimapBtnPosition = math.degrees(angle)
        UpdateMinimapButtonPos()
    end)
end)

minimapBtn:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate", nil)
end)

minimapBtn:SetScript("OnClick", function(self, button)
    if button == "LeftButton" then
        if frame:IsShown() then
            frame:Hide()
        else
            frame:Show()
        end
    else
        SendSyncRequest()
        DEFAULT_CHAT_FRAME:AddMessage("|cff00ffff[Invasions]: Sync requested!|r")
    end
end)

-- Minimap Button Tooltip
minimapBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("Zone Invasions")
    GameTooltip:AddLine("Left-Click to toggle tracker panel.", 1, 1, 1)
    GameTooltip:AddLine("Right-Click to force update status.", 1, 1, 1)
    GameTooltip:Show()
end)

minimapBtn:SetScript("OnLeave", function(self)
    GameTooltip:Hide()
end)

-- World Map Overlay Banner
local mapOverlay = CreateFrame("Frame", "InvasionsMapOverlay", WorldMapDetailFrame)
mapOverlay:SetSize(360, 44)
mapOverlay:SetPoint("TOP", WorldMapDetailFrame, "TOP", 0, -10)
mapOverlay:SetFrameLevel(10)
mapOverlay:Hide()

mapOverlay:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
mapOverlay:SetBackdropColor(0.4, 0.05, 0.05, 0.85) -- Translucent danger red
mapOverlay:SetBackdropBorderColor(1.0, 0.2, 0.2, 0.9) -- Glowing red

local overlayText = mapOverlay:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
overlayText:SetPoint("CENTER", 0, 0)
overlayText:SetTextColor(1.0, 0.82, 0.0) -- Gold

local function UpdateMapOverlay()
    if not WorldMapFrame:IsShown() then
        mapOverlay:Hide()
        return
    end
    
    local mapAreaId = GetCurrentMapAreaID()
    local status = activeInvasions[mapAreaId]
    
    if status and status.theme ~= "Safe" then
        overlayText:SetText(string.format("WARNING: ACTIVE %s!\nPhase %d in progress.", string.upper(status.theme), status.phase))
        mapOverlay:Show()
    else
        mapOverlay:Hide()
    end
end

-- Cinematic Invasion Alert Banner
local alertFrame = CreateFrame("Frame", "InvasionsAlertFrame", UIParent)
alertFrame:SetSize(520, 70)
alertFrame:SetPoint("TOP", 0, -180)
alertFrame:Hide()

alertFrame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
alertFrame:SetBackdropColor(0.06, 0.01, 0.01, 0.85) -- Translucent deep red/dark background
alertFrame:SetBackdropBorderColor(1.0, 0.2, 0.2, 0.8)

local alertTitle = alertFrame:CreateFontString(nil, "OVERLAY")
alertTitle:SetFont("Fonts\\FRIZQT__.TTF", 20, "OUTLINE")
alertTitle:SetPoint("TOP", 0, -12)
alertTitle:SetTextColor(1.0, 0.2, 0.2)

local alertSub = alertFrame:CreateFontString(nil, "OVERLAY")
alertSub:SetFont("Fonts\\FRIZQT__.TTF", 13, "OUTLINE")
alertSub:SetPoint("BOTTOM", 0, 12)
alertSub:SetTextColor(1.0, 1.0, 1.0)

local animTime = 0
local totalDuration = 7.0
local fadeInDuration = 0.5
local fadeOutDuration = 1.5

alertFrame:SetScript("OnUpdate", function(self, elapsed)
    animTime = animTime + elapsed
    if animTime >= totalDuration then
        self:Hide()
        return
    end

    -- Calculate Alpha
    local alpha = 1.0
    if animTime < fadeInDuration then
        alpha = animTime / fadeInDuration
    elseif animTime > (totalDuration - fadeOutDuration) then
        alpha = (totalDuration - animTime) / fadeOutDuration
    end
    self:SetAlpha(alpha)

    -- Pulsing color between Red (1, 0.1, 0.1) -> Orange (1, 0.5, 0.1) -> Yellow (1, 0.9, 0.1)
    local pulseSpeed = 6.0 -- radians per sec
    local pulse = (math.sin(animTime * pulseSpeed) + 1) / 2
    
    local r, g, b
    if pulse < 0.5 then
        local t = pulse * 2
        r = 1.0
        g = 0.1 + 0.4 * t
        b = 0.1
    else
        local t = (pulse - 0.5) * 2
        r = 1.0
        g = 0.5 + 0.4 * t
        b = 0.1
    end
    
    alertTitle:SetTextColor(r, g, b)
    self:SetBackdropBorderColor(r, g, b, 0.8)
end)

local function ShowInvasionAlert(isWarning, zoneId, themeName)
    local zConf = INVASION_ZONES[zoneId]
    local zoneName = zConf and zConf.name or "Unknown Zone"
    
    if isWarning then
        alertTitle:SetText("WARNING: INVASION IMMINENT")
        alertSub:SetText(string.format("High-energy signatures detected in %s!", zoneName))
        PlaySound("RaidWarning")
    else
        local theme = themeName or "Unknown Forces"
        alertTitle:SetText("INVASION STARTED!")
        alertSub:SetText(string.format("%s has begun in %s!", theme, zoneName))
        PlaySound("RaidWarning")
        PlaySound("PVPFlagCaptured")
    end
    
    animTime = 0
    alertFrame:SetAlpha(0)
    alertFrame:Show()
end

-- Network/Addon Msg Event Register
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("WORLD_MAP_UPDATE")

eventFrame:SetScript("OnEvent", function(self, event, prefix, msg, channel, sender)
    if event == "ADDON_LOADED" and prefix == "InvasionsSystem" then
        UpdateMinimapButtonPos()
    elseif event == "PLAYER_LOGIN" then
        RegisterAddonMessagePrefix(ADDON_PREFIX)
        UpdateMinimapButtonPos()
        SendSyncRequest()
    elseif event == "WORLD_MAP_UPDATE" then
        UpdateMapOverlay()
    elseif event == "CHAT_MSG_ADDON" and prefix == ADDON_PREFIX then
        if msg:find("^Sync:") then
            -- Format: Sync:GM=1|ZoneId,Theme,Phase,Remaining,Phase2Active|ZoneId,...
            local rawData = msg:sub(6)
            local gmPrefix, data = string.match(rawData, "^GM=(%d+)|(.*)")
            
            if gmPrefix then
                isGM = (gmPrefix == "1")
            else
                isGM = false
                data = rawData
            end
            
            -- Parse invasions list
            activeInvasions = {}
            if data and data ~= "" then
                for entry in string.gmatch(data, "([^|]+)") do
                    local zoneId, theme, phase, remaining, phase2 = string.match(entry, "([^,]+),([^,]+),([^,]+),([^,]+),([^,]+)")
                    if zoneId then
                        local zNum = tonumber(zoneId)
                        activeInvasions[zNum] = {
                            theme = theme,
                            phase = tonumber(phase) or 0,
                            remaining = tonumber(remaining) or 0,
                            phase2 = (phase2 == "1")
                        }
                    end
                end
            end
            
            RefreshUI()
            UpdateMapOverlay()
        elseif msg:find("^Warning:") then
            local zoneId = tonumber(msg:match("^Warning:(%d+)"))
            if zoneId then
                ShowInvasionAlert(true, zoneId)
                SendSyncRequest()
            end
        elseif msg:find("^Start:") then
            local zoneId, themeName = msg:match("^Start:(%d+),(.+)")
            if zoneId then
                ShowInvasionAlert(false, tonumber(zoneId), themeName)
                SendSyncRequest()
            end
        end
    end
end)

-- Slash Commands
SLASH_INVASIONS1 = "/invasions"
SLASH_INVASIONS2 = "/invasion"
SLASH_INVASIONS3 = "/inv"
SlashCmdList["INVASIONS"] = function(msg)
    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
    end
end

DEFAULT_CHAT_FRAME:AddMessage("|cff00ffffInvasions Tracker Addon loaded! Type /invasions or click the minimap icon.|r")
